ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterServerCallback("esx_hospital:checkUp", function(source,cb)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    if Config.price~=0 and xPlayer.getMoney()>=Config.price then
        cb(true)
        Wait(15000)
        xPlayer.removeMoney(Config.price)
        TriggerClientEvent('esx:showNotification', _source, '~r~You paid ~g~$'..Config.price)
    elseif Config.price~=0 and xPlayer.getMoney()<Config.price then
        TriggerClientEvent('esx:showNotification', _source, '~r~You don\'t have enough money!')
        cb(false)
    elseif Config.price==0 then cb(true) end
end)