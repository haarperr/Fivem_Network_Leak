ESX = nil
local bedHashes = {}

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
    end
end)

function putInBed(ped,pos,heading)
    DoScreenFadeOut(750)
    Wait(760)
    SetEntityCoordsNoOffset(ped, pos, 0, 0, 0)
    SetEntityHeading(ped, heading)
    ESX.Streaming.RequestAnimDict("missfbi5ig_0",function()
        TaskPlayAnim(ped, "missfbi5ig_0", "lyinginpain_loop_steve", 8.0, 1.0, 15000, 45, 1.0, 0, 0, 0)
        DoScreenFadeIn(760)
        Wait(15000)
        SetEntityHealth(ped,200)
        ClearPedBloodDamage(ped)
        ResetPedVisibleDamage(ped)
    end)
end

Citizen.CreateThread(function()
    local bed = nil
    for k,v in ipairs(Config.beds) do table.insert(bedHashes,GetHashKey(v)) end
    while true do
        local ped = GetPlayerPed(-1)
        Citizen.Wait(0)
        if GetDistanceBetweenCoords(vector3(Config.marker.x,Config.marker.y,Config.marker.z), GetEntityCoords(ped), false)<50 then
            DrawMarker(1, Config.marker.x, Config.marker.y, Config.marker.z, 0, 0, 0, 0, 0, 0, 1.1, 1.1, 0.4, 255, 255, 255, 200, false, false, 0, false, 0, 0, 0)
            if GetDistanceBetweenCoords(vector3(Config.marker.x,Config.marker.y,Config.marker.z), GetEntityCoords(ped), false)<1.1 then
                ESX.ShowHelpNotification('Hit ~INPUT_CONTEXT~ to go to the hospital')
                if IsControlJustPressed(0, 51) then
                    local health = GetEntityHealth(ped)
                    if health>=200 then
                        ESX.ShowNotification("~g~Your health is already full!")
                    else
                        ESX.TriggerServerCallback("esx_hospital:checkUp", function(can)
                            if can then
                                ClearPedTasksImmediately(ped)
                                if Config.enable_bed_models and #bedHashes>0 then
                                    for k,v in ipairs(bedHashes) do
                                        bed = GetClosestObjectOfType(GetEntityCoords(ped), 100.0, v, false, false, false)
                                        if bed ~= 0 then
                                            break
                                        end
                                    end
                                    if bed ~= nil and DoesEntityExist(bed) then
                                        local bedCoords = GetEntityCoords(bed)
                                        putInBed(ped,bedCoords,GetEntityHeading(bed)+180)
                                    end
                                else
                                    putInBed(ped,vector3(Config.bed.x,Config.bed.y,Config.bed.z),Config.bed.heading)
                                end
                            end
                        end)
                    end
                end
            end
        end
    end
end)