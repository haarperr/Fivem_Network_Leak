Config = {}
Config.enable_bed_models = false -- enable tping onto the closest bed prop found, list of valid props is below
Config.beds = {
    -- "v_med_bed1", -- these are custom models https://forum.fivem.net/t/release-hospital-props/151753
    -- "v_med_bed2"
}
Config.marker = {
    x = 0.0,
    y = 0.0,
    z = 0.0
}
Config.bed = {
    x = 0.0,
    y = 0.0,
    z = 0.0,
    heading = 0
}
Config.price = 60 -- price for visiting the hospital and getting healed up, set to 0 to disable