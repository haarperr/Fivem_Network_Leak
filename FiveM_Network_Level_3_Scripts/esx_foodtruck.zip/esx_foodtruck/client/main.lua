local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}

ESX = nil

local MenuOpened = false
local Closest = false
local LastPed

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)

        local player = GetPlayerPed(-1)
        local veh = GetVehiclePedIsIn(player)
        local pid = PlayerPedId()
        local playerloc = GetEntityCoords(player, 0)
        local handle, ped = FindFirstPed()
        Closest = false
        local success

        repeat
            success, ped = FindNextPed(handle)
            local pos = GetEntityCoords(ped)
            local distance = GetDistanceBetweenCoords(pos.x, pos.y, pos.z, playerloc['x'], playerloc['y'], playerloc['z'], true)

            if DoesEntityExist(ped)then
                if not IsPedDeadOrDying(ped) then
                    local pedType = GetPedType(ped)
                    if pedType ~= 28 and not IsPedAPlayer(ped) then
                        if distance ~= 0.0 and distance < Config.sellDistance then
                            if veh ~= 0 and GetHashKey(Config.vehicle) == GetEntityModel(veh) and not IsPedInAnyVehicle(ped) and GetEntitySpeed(veh) == 0.0 then
                                if not Closest and LastPed ~= ped then
                                    Closest = ped
                                elseif distance < GetDistanceBetweenCoords(GetEntityCoords(closest), playerloc['x'], playerloc['y'], playerloc['z'], true) and LastPed ~= ped then
                                    Closest = ped
                                end
                            end
                        end
                    end
                end
            end

        until not success

        EndFindPed(handle)

        if Closest then
            local coords = GetEntityCoords(Closest)
            DrawMarker(0, coords.x, coords.y, coords.z + 1.05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.2, 180, 0, 0, 200, false, true, 2, false, false, false, false)
        end

        local veh = GetVehiclePedIsIn(GetPlayerPed(-1))

        if Closest and GetEntitySpeed(veh) == 0.0 then
            local destiny = GetEntityCoords(GetPlayerPed(-1))
            TaskPedSlideToCoord(Closest, destiny, 180.0, 2000)
            if GetDistanceBetweenCoords(destiny, GetEntityCoords(Closest)) < 2 and LastPed ~= Closest then
                local item = math.random(1, #Config.AllowedItems)
                ESX.TriggerServerCallback("esx_foodtruck:sell", function (result)
                    if result then
                        ESX.Streaming.RequestAnimDict('mp_player_inteat@burger', function()
                            TaskPlayAnim(Closest, 'mp_player_inteat@burger', 'mp_player_int_eat_burger_fp', 8.0, -8, -1, 49, 0, 0, 0, 0)
                            Citizen.Wait(3000)
                            ClearPedTasks(Closest)
                            LastPed = Closest
                        end)
                    else
                        ClearPedTasks(Closest)
                        LastPed = Closest
                    end
                end, Config.AllowedItems[item].item, Config.AllowedItems[item].price)
                Wait(5000)
            end
        end

    end
end)