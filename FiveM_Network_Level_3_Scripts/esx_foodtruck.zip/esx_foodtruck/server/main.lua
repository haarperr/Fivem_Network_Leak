ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- SELL ITEM TO NPC
ESX.RegisterServerCallback('esx_foodtruck:sell', function(source, cb, item, price)
	local xPlayer = ESX.GetPlayerFromId(source)
	local GetItem = xPlayer.getInventoryItem(item)

	if GetItem.count > 0 then
		xPlayer.addMoney(price)
		xPlayer.removeInventoryItem(item, 1)
		cb(true)
		TriggerClientEvent('esx:showNotification', source, _U('sold', GetItem.label, price))
	else
		cb(false)
		TriggerClientEvent('esx:showNotification', source, _U('missing_item', GetItem.label))
	end
end)

--GET INVENTORY ITEM
ESX.RegisterServerCallback('esx_foodtruck:getInventory', function(source, cb)
  local xPlayer = ESX.GetPlayerFromId(source)
  local items   = xPlayer.inventory

  cb({items = items})

end)