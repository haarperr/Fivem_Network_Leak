Config               = {}
Config.Locale        = 'en'

Config.sellDistance = 10.0
Config.vehicle = "taco"

Config.AllowedItems = {
	{item = "bread", price = 5},
	{item = "water", price = 7},
}