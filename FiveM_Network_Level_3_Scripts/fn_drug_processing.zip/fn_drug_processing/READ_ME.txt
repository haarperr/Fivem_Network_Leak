FEATURES:
- Harvest, process, sell drugs in the drug labs from GTA:O

REQUIREMENTS:
- ESX
- esx_drugs_custom (https://github.com/madhatter23412/esx_drugs_custom)
- fivem-ipl (https://github.com/ESX-PUBLIC/fivem-ipl)

INSTALLATION:
- Import sql.sql in your database
- Edit config of esx_drugs to hide points you won't be using
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_drug_processing

CREDITS:
- Elipse458
