ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterServerCallback("fn_drug_processing:getOwnedLabs",function(source,cb)
    local identifier = ESX.GetPlayerFromId(source).identifier
    MySQL.Async.fetchAll("SELECT * FROM fn_drug_labs_owned WHERE identifier=@identifier",{["@identifier"]=identifier},function(data)
        local cbdata = {}
        for k,v in ipairs(data) do table.insert(cbdata,v.lab) end
        cb(cbdata)
    end)
end)

RegisterServerEvent("fn_drug_processing:buyLab")
AddEventHandler("fn_drug_processing:buyLab",function(lab)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local labdata = Config.labs[lab]
    if lab then
        if xPlayer.getMoney()>=labdata.price then
            xPlayer.removeMoney(labdata.price)
            MySQL.Async.execute("INSERT INTO fn_drug_labs_owned(id,lab,identifier) VALUES(NULL,@lab,@identifier)",{["@lab"]=lab,["@identifier"]=xPlayer.identifier})
            TriggerClientEvent("esx:showNotification",_source,"~g~You bought this lab for $"..tostring(ESX.Math.GroupDigits(labdata.price)))
            TriggerClientEvent("fn_drug_processing:boughtLab",_source,lab)
        else
            TriggerClientEvent("esx:showNotification",_source,"~r~You don't have enough money!")
        end
    end
end)

Citizen.CreateThread(function()
    Citizen.Wait(5000) -- wait for players to actually make a script environment for the client script
    local players = GetPlayers()
    for _,player in ipairs(players) do TriggerClientEvent("fn_drug_processing:midRestart",player) end
end)