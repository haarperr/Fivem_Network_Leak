ESX = nil
local labs = {meth=1,weed=2,coke=3}
local owned = {false,false,false}
local harvesting,processing,selling = false,false,false
local inside = nil
local job = ""

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
    end
    if PlayerData==nil then PlayerData = ESX.GetPlayerData() end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    job = xPlayer.job.name
    ESX.TriggerServerCallback("fn_drug_processing:getOwnedLabs",function(labs)
        for k,v in ipairs(labs) do
            owned[v]=true
        end
    end)
end)

RegisterNetEvent("fn_drug_processing:midRestart")
AddEventHandler("fn_drug_processing:midRestart",function()
    job = ESX.GetPlayerData().job.name
    ESX.TriggerServerCallback("fn_drug_processing:getOwnedLabs",function(labs)
        for k,v in ipairs(labs) do
            owned[v]=true
        end
    end)
end)

RegisterNetEvent("fn_drug_processing:boughtLab")
AddEventHandler("fn_drug_processing:boughtLab",function(lab)
    owned[lab]=true
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if job~="police" or Config.police_can_enter then
            local playerPed = GetPlayerPed(-1)
            local playerPos = GetEntityCoords(GetPlayerPed(-1)) -- cant use playerPed here for some reason?
            for k,v in ipairs(Config.labs) do
                if owned[k] or job=="police" then
                    if GetDistanceBetweenCoords(playerPos, v.enter, false)<15.0 then
                        DrawMarker(1, v.enter.x, v.enter.y, v.enter.z-1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 0.25, 0, 0, 255, 100, 0, 0, 0, false)
                        if GetDistanceBetweenCoords(playerPos, v.enter, false)<1.0 then
                            ESX.ShowHelpNotification("Press ~INPUT_CONTEXT~ to enter ~b~"..v.label)
                            if IsControlJustPressed(0, 51) then
                                inside = k
                                DoScreenFadeOut(250)
                                Citizen.Wait(250)
                                SetEntityCoords(playerPed, v.enterpos.x, v.enterpos.y, v.enterpos.z)
                                Citizen.Wait(250)
                                DoScreenFadeIn(350)
                            end
                        end
                    elseif GetDistanceBetweenCoords(playerPos, v.leave, false)<15.0 then
                        DrawMarker(1, v.leave.x, v.leave.y, v.leave.z-1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 0.25, 255, 0, 0, 100, 0, 0, 0, false)
                        if GetDistanceBetweenCoords(playerPos, v.leave, false)<1.0 then
                            ESX.ShowHelpNotification("Press ~INPUT_CONTEXT~ to exit ~b~"..v.label)
                            if IsControlJustPressed(0, 51) then
                                TriggerEvent('esx_drugs:hasExitedMarker',"")
                                inside,harvesting,processing,selling = nil,false,false,false
                                DoScreenFadeOut(250)
                                Citizen.Wait(250)
                                SetEntityCoords(playerPed, v.leavepos.x, v.leavepos.y, v.leavepos.z)
                                Citizen.Wait(250)
                                DoScreenFadeIn(350)
                            end
                        end
                    end
                else
                    if GetDistanceBetweenCoords(playerPos, v.enter, false)<15.0 then
                        DrawMarker(1, v.enter.x, v.enter.y, v.enter.z-1, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 0.25, 0, 255, 0, 100, 0, 0, 0, false)
                        if GetDistanceBetweenCoords(playerPos, v.enter, false)<1.0 then
                            ESX.ShowHelpNotification("Press ~INPUT_CONTEXT~ to buy ~b~"..v.label.."~s~ for ~r~$"..ESX.Math.GroupDigits(v.price))
                            if IsControlJustPressed(0, 51) then
                                TriggerServerEvent("fn_drug_processing:buyLab",k)
                            end
                        end
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function()
    local harvest = {'esx_drugs:startHarvestMeth','esx_drugs:startHarvestWeed','esx_drugs:startHarvestCoke'}
    local process = {'esx_drugs:startTransformMeth','esx_drugs:startTransformWeed','esx_drugs:startTransformCoke'}
    local sell = {'esx_drugs:startSellMeth','esx_drugs:startSellWeed','esx_drugs:startSellCoke'}
    while true do
        Citizen.Wait(0)
        if inside~=nil and job~="police" then
            local lab = Config.labs[inside]
            local helptext = (lab.harvest and not harvesting) and "Press ~INPUT_DETONATE~ to harvest" or ""
            helptext = (lab.process and not processing) and (helptext~="" and helptext..", ~INPUT_REPLAY_SCREENSHOT~ to process" or "Press ~INPUT_REPLAY_SCREENSHOT~ to process") or helptext
            helptext = (lab.sell and not selling) and (helptext~="" and helptext..", ~INPUT_ARREST~ to sell" or "Press ~INPUT_ARREST~ to sell") or helptext
            if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), lab.leave, false)>1.0 then ESX.ShowHelpNotification(helptext) end
            if IsControlPressed(0, 47) and lab.harvest and not harvesting then TriggerServerEvent(harvest[inside]); harvesting = true end
            if IsControlPressed(0, 303) and lab.process and not processing then TriggerServerEvent(process[inside]); processing = true end
            if IsControlPressed(0, 49) and lab.sell and not selling then TriggerServerEvent(sell[inside]); selling = true end
        end
    end
end)