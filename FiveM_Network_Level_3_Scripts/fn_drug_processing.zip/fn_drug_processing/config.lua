local labs = {meth=1,weed=2,coke=3} -- do not edit this line, only if you know what you're doing
Config = {}
Config.police_can_enter = false -- cops can enter these labs
Config.labs = {
    [labs.meth] = {
        label = "Meth Lab", -- name of the lab
        price = 550000, -- price of the lab
        enter = vector3(399.7571, 66.50323, 97.97794), -- enter marker
        enterpos = vector3(997.8272, -3198.966, -36.39367), -- position to be tped to after using enter marker
        leave = vector3(997.1337, -3200.702, -36.39367), -- leave marker
        leavepos = vector3(399.2189, 64.90705, 97.97794), -- position to be tped to after using leave marker
        harvest = false, -- can harvest?
        process = true, -- can process?
        sell = false -- can sell?
    },
    [labs.weed] = {
        label = "Weed Farm",
        price = 350000,
        enter = vector3(101.9525, 175.0028, 104.5948),
        enterpos = vector3(1062.881, -3184.432, -39.16407),
        leave = vector3(1066.171, -3183.496, -39.16359),
        leavepos = vector3(101.0681, 172.7552, 104.5817),
        harvest = true,
        process = true,
        sell = false
    },
    [labs.coke] = {
        label = "Cocaine Lockup",
        price = 425000,
        enter = vector3(-622.8288, 311.6622, 83.92879),
        enterpos = vector3(1088.526, -3190.74, -38.99348),
        leave = vector3(1088.781, -3187.609, -38.99348),
        leavepos = vector3(-622.2003, 310.1617, 83.92972),
        harvest = false,
        process = true,
        sell = false
    }
}