var Config = {
    ingredients:{
        antifreeze: { // <-- spawn name of item
            img: "https://i.elipse458.me/8877ed7", // <-- image to show in crafting screen
            label: "Anti-freeze" // <-- label to show on crafting screen when hovering over item
        }, // js array items are separated by commas
        sudafed: {
            img: "https://i.elipse458.me/45ce7de",
            label: "Sudafed"
        } // js arrays don't have commas at the end
    }
}

var Recipes = {
    acetone: { // <-- spawn name of item
        items: ["antifreeze","sudafed"], // <-- crafting recipe (order matters)
        result_label: "Weird Chemical", // <-- label to show when hovering over result
        count: 1, // <-- how many items to give when crafted
        result_img: "https://i.elipse458.me/57c1125" // <-- image to show in result
    }, // js array items are separated by commas
    redphosphorus: {
        items: ["antifreeze","sudafed","antifreeze"],
        result_label: "Weird Chemical #2",
        count: 1,
        result_img: "https://i.elipse458.me/placeholder"
    } // js arrays don't have commas at the end
};