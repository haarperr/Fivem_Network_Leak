function menuToggle(state, send) {
    if(state) {
        $(".container").show();
    } else {
        $(".container").hide();
        $(".ui-tooltip").remove();
    }
    if(send)
        $.post("http://fn_crafting/toggle",JSON.stringify({state:state}));
}

function createItem(name) {
    if(Config.ingredients[name]!=null) {
        $(".crafting-ingredients").append('<div class="crafting-ingredient" data-item="'+name+'"><img src="'+Config.ingredients[name].img+'" title="'+Config.ingredients[name].label+'" /></div>');
    }
}

function sortIngredients() {
    var sorted = $('.crafting-ingredient:not(.crafting-area .crafting-ingredient)').sort(function(a, b) { return String.prototype.localeCompare.call($(a).data('item').toLowerCase(), $(b).data('item').toLowerCase()); });
    $(".crafting-ingredients").empty().append(sorted);
}

function checkCrafting() {
    var cancraft = undefined;
    for(x in Recipes) {
        const recipe = Recipes[x];
        var cancraftthis = $($(".crafting-area .crafting-ingredient")[0]).data("item")==recipe.items[0];
        if(recipe.items.length==$(".crafting-area .crafting-ingredient").length) {
            $(".crafting-area .crafting-ingredient").each(function(e){
                cancraftthis = cancraftthis && $($(".crafting-area .crafting-ingredient")[e]).data("item")==recipe.items[e];
            });
            cancraft = cancraftthis ? x : cancraft;
        }
    }
    if(cancraft!=undefined) {
        var recipe = Recipes[cancraft];
        $(".crafting-result").html('<img src="'+recipe.result_img+'" title="'+recipe.result_label+'" />');
        $(".crafting-result").data("item",cancraft);
        console.log("Cancraft: "+cancraft);
    } else if(cancraft==undefined && $(".crafting-result").html()!="") {
        $(".crafting-result").html("");
        $(".crafting-result").data("item","");
    }
}

$(function(){
    menuToggle(false,false);
    $(document).tooltip();
    $(document).on("click",".crafting-ingredient",function(){
        $(this).appendTo(".crafting-area");
        $(".ui-tooltip").remove();
        setTimeout(function(){
            checkCrafting();
            sortIngredients();
        },1);
    });
    $(document).on("click",".crafting-area .crafting-ingredient",function(){
        $(this).appendTo(".crafting-ingredients");
        setTimeout(function(){
            checkCrafting();
            sortIngredients();
        },1);
    });
    $(document).on("click",".crafting-result",function(){
        var resultitem = $(this).data("item");
        if(resultitem!=null) {
            $(".crafting-area").empty();
            $(this).html("");
            $.post("http://fn_crafting/craft",JSON.stringify({item:resultitem}));
            if(Config.ingredients[resultitem]!=null) {
                for (let _ = 0; _ < Recipes[resultitem].count; _++) {
                    createItem(resultitem);
                }
                sortIngredients();
            }
        }
    });
    document.onkeyup = function (data) {
        if (data.which == 27) {
            menuToggle(false,true);
        }
    };
	window.addEventListener('message', function(event){
		if(event.data.type=="togglemenu") {
            console.log(event.data);
			if(event.data.items!=null) {
                $(".crafting-ingredients").empty();
				for(item in event.data.items) {
                    console.log(item);
                    for(var _ = 0; _ < event.data.items[item]; _++) {
                        createItem(item);
                    }
                }
                sortIngredients();
			}
			menuToggle(event.data.state,false);
		}
	});
});