resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_script "client.lua"
server_script "server.js"

files {
    "html/index.html",
    "html/style.css",
    "html/config.js",
    "html/script.js"
}

ui_page "html/index.html"