FEATURES:
- Adds a crafting screen where you can craft items

REQUIREMENTS:
- ESX

INSTALLATION:
- Put the resource in your resources directory
- Change stuff in html/config.js
- Add this in your server.cfg
   start fn_crafting

CREDITS:
- Elipse458
