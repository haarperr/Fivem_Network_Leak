var ESX = null;
eval(LoadResourceFile(GetCurrentResourceName(),"html/config.js")); // load config.js

emit('esx:getSharedObject', function(obj){ ESX = obj; });

setImmediate(function(){
    while(ESX==null) {
    }
    ESX.RegisterServerCallback("fn_crafting:craft",function(source,cb,resitem){
        var xPlayer = ESX.GetPlayerFromId(source);
        var recipe = Recipes[resitem];
        if(recipe!=null) {
            var itemcounts = {};
            var cancraft = true;
            for(item in recipe.items) {
                itemcounts[recipe.items[item]] = itemcounts[recipe.items[item]]!=null ? itemcounts[recipe.items[item]]++ : 1;
            }
            console.log(itemcounts);
            for(item in itemcounts) {
                cancraft = cancraft && xPlayer.getInventoryItem(item).count>=itemcounts[item];
            }
            cb(cancraft);
            if(cancraft) {
                for(item in itemcounts) {
                    xPlayer.removeInventoryItem(item,itemcounts[item]);
                }
                xPlayer.addInventoryItem(resitem,recipe.count);
            } else {
                emitNet("esx:showNotification",source,"~r~You don't have the required ingredients!"); // idk how anyone gets here without cheats or a weird bug
            }
        }
    });
    ESX.RegisterServerCallback("fn_crafting:getItems",function(source,cb){
        var xPlayer = ESX.GetPlayerFromId(source);
        var items = xPlayer.getInventory();
        var cbitems = {};
        for(item in items) {
            cbitems[items[item].name] = items[item].count;
        }
        cb(cbitems);
    });
});