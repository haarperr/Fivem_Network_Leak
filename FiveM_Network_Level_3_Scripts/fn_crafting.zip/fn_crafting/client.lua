local openkey = 344 -- F11


---- dont touch anything under this line ----
ESX = nil
local menu = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function toggleMenu(state,send)
    menu = state
    SetNuiFocus(state, state)
    if send then
        ESX.TriggerServerCallback("fn_crafting:getItems", function(items)
            SendNuiMessage(json.encode({type = "togglemenu", state = state, items = items}))
        end)
    end
end

RegisterNUICallback("toggle",function(data,cb)
    toggleMenu(data.state,false)
end)

RegisterNUICallback("craft",function(data,cb)
    ESX.TriggerServerCallback("fn_crafting:craft", function(can)
        if not can then
            toggleMenu(true,true)
        end
    end, data.item)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, openkey) and not menu then toggleMenu(true, true) end
    end
end)

RegisterCommand("nuidebug",function(a,b,c) SetNuiFocus(false,false) end, false)