cfg = {}

cfg.hotwirechance = 75 -- chance of being hotwired in percentage
cfg.hotwiretime = 7.0 -- how long hotwire should take in seconds
cfg.lockpickbreakchance = 50 -- chance of lockpick breaing

cfg.whitelist = {
  "police",
  "ambulance"
}