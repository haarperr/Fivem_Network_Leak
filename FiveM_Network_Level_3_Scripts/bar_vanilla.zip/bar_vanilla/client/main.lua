ESX = nil

Citizen.CreateThread(function()
    Citizen.Wait(1)

    while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    
    Citizen.Wait(1)
        local blip = AddBlipForCoord(127.28, -1284.56, 28.30)
        SetBlipSprite (blip, 93)
        SetBlipDisplay(blip, 4)
        SetBlipScale  (blip, 0.8)
        SetBlipColour (blip, 69)
        SetBlipAsShortRange(blip, true)
    
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(Config.BarName)
        EndTextCommandSetBlipName(blip)

    while true do
        Citizen.Wait(1)
        local coords = GetEntityCoords(PlayerPedId(), true)
            if GetDistanceBetweenCoords(128.303, -1285.489, 29.28, coords) < 0.5 then
                ESX.ShowNotification(Config.ShowHelpNoty)
                if IsControlJustReleased(0, 47) then
                    WarMenu.OpenMenu('Vanilla Main')
                    Citizen.Wait(1000)
            end
        end
    end
end)

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

function drink(prop, q)
    RequestModel( GetHashKey( "S_M_Y_Waiter_01" ) )
    while ( not HasModelLoaded( GetHashKey( "S_M_Y_Waiter_01" ) ) ) do
    Citizen.Wait( 1 )
    end
    local ped = CreatePed(4, 0xAD4C724C, 128.44, -1279.92, 28.29, 304.335, true)
    SetEntityAsMissionEntity(ped)
    Wait(1500)
    RequestAnimDict("amb@prop_human_bum_bin@idle_b")
    while (not HasAnimDictLoaded("amb@prop_human_bum_bin@idle_b")) do Citizen.Wait(0) end
	Wait(200)
	TaskGoStraightToCoord(ped, 129.69, -1283.5, 28.29, 1, 2, 316.642, 5)
	Wait(3000)
	SetPedDesiredHeading(ped, 135.5)
	Wait(1000)
	TaskPlayAnim(ped,"amb@prop_human_bum_bin@idle_b","idle_d",100.0, 200.0, 0.3, 120, 0.2, 0, 0, 0)
	Wait(4000)
	StopAnimTask(ped, "amb@prop_human_bum_bin@idle_b","idle_d", 1.0)

    local playerPed = PlayerPedId()
    local x,y,z = table.unpack(GetEntityCoords(playerPed))
    prop = CreateObject(GetHashKey(prop), x, y, z+0.2,  true,  true, true)
    AttachEntityToEntity(prop, playerPed, GetPedBoneIndex(playerPed, 18905), 0.15, -0.005, 0.005, 270.0, 175.0, 0.0, true, true, false, true, 1, true)

    TaskGoStraightToCoord(ped, 127.699, -1280.205, 29.27, 1, 2, 316.642, 5)


    TaskPlayAnim(playerPed, 'amb@drinking@drinking_shots@glass@', 'idle_glass', 8.0, -8, -1, 49, 0, 0, 0, 0)
    for i=1, 50 do
        Wait(150)
        TriggerEvent('esx_status:add', 'thirst', q)
    end
    IsAnimated = false
    ClearPedSecondaryTask(playerPed)
    DeleteObject(prop)

    DeletePed(ped)

end

function bottle2(prop, q, a)

    RequestModel( GetHashKey( "S_M_Y_Waiter_01" ) )
    while ( not HasModelLoaded( GetHashKey( "S_M_Y_Waiter_01" ) ) ) do
    Citizen.Wait( 1 )
    end
    local ped = CreatePed(4, 0xAD4C724C, 128.44, -1279.92, 28.29, 304.335, true)
    SetEntityAsMissionEntity(ped)
    Wait(1500)
    RequestAnimDict("amb@prop_human_bum_bin@idle_b")
    while (not HasAnimDictLoaded("amb@prop_human_bum_bin@idle_b")) do Citizen.Wait(0) end
	Wait(200)
	TaskGoStraightToCoord(ped, 129.69, -1283.5, 28.29, 1, 2, 316.642, 5)
	Wait(3000)
	SetPedDesiredHeading(ped, 135.5)
	Wait(1000)
	TaskPlayAnim(ped,"amb@prop_human_bum_bin@idle_b","idle_d",100.0, 200.0, 0.3, 120, 0.2, 0, 0, 0)
	Wait(4000)
    StopAnimTask(ped, "amb@prop_human_bum_bin@idle_b","idle_d", 1.0)
    
    local playerPed = PlayerPedId()
    local x,y,z = table.unpack(GetEntityCoords(playerPed))
    prop = CreateObject(GetHashKey(prop), x, y, z,  true,  true, true)
    AttachEntityToEntity(prop, playerPed, GetPedBoneIndex(playerPed, 18905), 0.145, a, 0.010, 270.0, 160.0, 0.0, true, true, false, true, 1, true)
    RequestAnimDict('mp_player_intdrink')
    while not HasAnimDictLoaded('mp_player_intdrink') do
        Wait(0)
    end

    TaskGoStraightToCoord(ped, 127.699, -1280.205, 29.27, 1, 2, 316.642, 5)

    Wait(2000)

    DeletePed(ped)

    TaskPlayAnim(playerPed, 'mp_player_intdrink', 'loop_bottle', 8.0, -8, -1, 49, 0, 0, 0, 0)
    for i=1, 50 do
        Wait(300)
        TriggerEvent('esx_status:add', 'thirst', q)
        
    end
    IsAnimated = false
    ClearPedSecondaryTask(playerPed)
    DeleteObject(prop)
end

function eat(prop, q)
    RequestModel( GetHashKey( "S_M_Y_Waiter_01" ) )
    while ( not HasModelLoaded( GetHashKey( "S_M_Y_Waiter_01" ) ) ) do
    Citizen.Wait( 1 )
    end
    local ped = CreatePed(4, 0xAD4C724C, 128.44, -1279.92, 28.29, 304.335, true)
    SetEntityAsMissionEntity(ped)
    Wait(1500)
    RequestAnimDict("amb@prop_human_bum_bin@idle_b")
    while (not HasAnimDictLoaded("amb@prop_human_bum_bin@idle_b")) do Citizen.Wait(0) end
	Wait(200)
	TaskGoStraightToCoord(ped, 129.69, -1283.5, 28.29, 1, 2, 316.642, 5)
	Wait(3000)
	SetPedDesiredHeading(ped, 135.5)
	Wait(1000)
	TaskPlayAnim(ped,"amb@prop_human_bum_bin@idle_b","idle_d",100.0, 200.0, 0.3, 120, 0.2, 0, 0, 0)
	Wait(4000)
    StopAnimTask(ped, "amb@prop_human_bum_bin@idle_b","idle_d", 1.0)

    local playerPed = PlayerPedId()
    local x,y,z = table.unpack(GetEntityCoords(playerPed))
    prop = CreateObject(GetHashKey(prop), x, y, z+0.2,  true,  true, true)
    AttachEntityToEntity(prop, playerPed, GetPedBoneIndex(playerPed, 18905), 0.12, 0.028, 0.001, 10.0, 175.0, 0.0, true, true, false, true, 1, true)
    RequestAnimDict('mp_player_inteat@burger')
    while not HasAnimDictLoaded('mp_player_inteat@burger') do
        Wait(0)
    end

    TaskGoStraightToCoord(ped, 127.699, -1280.205, 29.27, 1, 2, 316.642, 5)

    Wait(2000)

    DeletePed(ped)

    TaskPlayAnim(playerPed, 'mp_player_inteat@burger', 'mp_player_int_eat_burger_fp', 8.0, -8, -1, 49, 0, 0, 0, 0)
    for i=1, 50 do
        Wait(300)
        TriggerEvent('esx_status:add', 'hunger', q)
    end
    IsAnimated = false
    ClearPedSecondaryTask(playerPed)
    DeleteObject(prop)
end
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
