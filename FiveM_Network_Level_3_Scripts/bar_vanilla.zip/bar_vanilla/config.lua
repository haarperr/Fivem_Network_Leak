Config = {}

Config.ShowHelpNoty = "~g~Press ~y~G~g~ to interact with the barman"

Config.BarName = "Vanilla Unicorn"



Config.BeerProp = "prop_cs_beer_bot_02"

Config.WhiskeyProp = "prop_cs_whiskey_bottle"

Config.CognacProp = "prop_bottle_cognac"

Config.RumProp = "prop_rum_bottle"

Config.CherenkovProp = "prop_cherenkov_01"

Config.eColaProp = "prop_pinacolada"

Config.HamburgerProp = "prop_cs_burger_01"

Config.HotDogProp = "prop_cs_hotdog_01"

Config.DonutProp = "prop_amb_donut"



Config.BeerPrice = 100

Config.WhiskeyPrice = 200

Config.CognacPrice = 100

Config.RumPrice = 200

Config.CherenkovPrice = 300

Config.eColaPrice = 10

Config.HotDogPrice = 30

Config.CheeseBurgerPrice = 50

Config.DonutPrice = 5