### How to install

1.) Put the script into your resource folder
2.) Make sure you added `start fn_idcard` in your server config

### How to use

1.) Use command `idcard` for open the card

### Other

1.) Do not rename the script!

### end

FiveM.Network