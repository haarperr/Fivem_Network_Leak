local cachedStats = {}

--[[
#### ADMIN COMMANDS ####
]]--

TriggerEvent('es:addAdminCommand', 'statset', 10, function(source, args, user)
	table.remove(args, 1)
	if args[1] and args[2] and args[3] then
		TriggerClientEvent("stats:set", source, tostring(args[1]), tostring(args[2]), tonumber(args[3]))
	else
		TriggerClientEvent('chatMessage', source, "Stats", {255, 0, 0}, "/statset <stamina|lung_capacity|strength> <xp|lvl|\"\"> <value>")
	end
end, function(source, args, user)
	TriggerClientEvent('chatMessage', source, "SYSTEM", {255, 0, 0}, "You don't have permissions to use this command!")
end, {})



TriggerEvent('es:addAdminCommand', 'saveallstats', 10, function(source, args, user)
	TriggerEvent("stats:saveAll")
end, function(source, args, user)
	TriggerClientEvent('chatMessage', source, "SYSTEM", {255, 0, 0}, "You don't have permissions to use this command!")
end, {})

TriggerEvent('es:addAdminCommand', 'showstatsxp', 10, function(source, args, user)
	TriggerClientEvent("stats:togglexp", source)
end, function(source, args, user)
	TriggerClientEvent('chatMessage', source, "SYSTEM", {255, 0, 0}, "You don't have permissions to use this command!")
end, {})

--[[
#### PLAYER COMMANDS ####
]]--

TriggerEvent('es:addCommand', 'stats', function(source, args, user)
	TriggerClientEvent("stats:getStats", source, function(stats)
		TriggerClientEvent("chatMessage", source, "Stats", {0, 200, 255}, _L("statscmd", ""))
		TriggerClientEvent("chatMessage", source, "", {255,255,255}, "^2".._L("stamina", "")..":^7 Level "..stats.stamina_lvl)
		TriggerClientEvent("chatMessage", source, "", {255,255,255}, "^2".._L("lung_capacity", "")..":^7 Level "..stats.lung_capacity_lvl)
		TriggerClientEvent("chatMessage", source, "", {255,255,255}, "^2".._L("strength", "")..":^7 Level "..stats.strength_lvl)
	end)
end)

--[[
#### IMPORTANT FUNCTION STUFF, DO NOT TOUCH ####
]]--

local ver = 1.0
Citizen.CreateThread(function()
	MySQL.ready(function ()
		MySQL.Async.execute('CREATE TABLE IF NOT EXISTS `stats` (`identifier` varchar(255) NOT NULL,`stamina` int(11) NOT NULL DEFAULT \'10\',`lung_capacity` int(11) NOT NULL DEFAULT \'10\',`strength` int(11) NOT NULL DEFAULT \'10\',`stamina_xp` float NOT NULL DEFAULT \'0\',`lung_capacity_xp` float NOT NULL DEFAULT \'0\',`strength_xp` float NOT NULL DEFAULT \'0\',`stamina_lvl` int(3) NOT NULL DEFAULT \'1\',`lung_capacity_lvl` int(3) NOT NULL DEFAULT \'1\',`strength_lvl` int(3) NOT NULL DEFAULT \'1\',PRIMARY KEY (`identifier`)) ENGINE=InnoDB DEFAULT CHARSET=latin1;', nil, nil)
	end)
end)

AddEventHandler('es:playerLoaded', function(player)
	local Identifier = GetPlayerIdentifiers(player)[1]
	MySQL.Async.fetchAll('SELECT * FROM stats WHERE `identifier`=@identifier;', {['@identifier'] = Identifier}, function(user)
		if user[1] then
			TriggerClientEvent("stats:playerLoaded", player, user[1])
			cachedStats[tonumber(player)] = user[1]
		else
			MySQL.Sync.execute('INSERT INTO `stats`(`identifier`) VALUES (@identifier);', {['@identifier'] = Identifier}, nil)
		end
		print("Stats: Stats loaded for "..GetPlayerName(player))
	end)
end)

AddEventHandler('playerDropped', function()
	local Identifier = GetPlayerIdentifiers(source)[1]
	local stats = cachedStats[tonumber(source)]
	if stats==nil then return end
	MySQL.Sync.execute('UPDATE `stats` SET `stamina`=@stamina,`lung_capacity`=@lung_capacity,`strength`=@strength,`stamina_xp`=@stamina_xp,`lung_capacity_xp`=@lung_capacity_xp,`strength_xp`=@strength_xp,`stamina_lvl`=@stamina_lvl,`lung_capacity_lvl`=@lung_capacity_lvl,`strength_lvl`=@strength_lvl WHERE `identifier`=@identifier;', {['@identifier'] = tostring(Identifier), ['@stamina'] = stats.stamina, ['@lung_capacity'] = stats.lung_capacity, ['@strength'] = stats.strength, ['@stamina_xp'] = stats.stamina_xp,['@lung_capacity_xp'] = stats.lung_capacity_xp,['@strength_xp'] = stats.strength_xp,['@stamina_lvl'] = stats.stamina_lvl,['@lung_capacity_lvl'] = stats.lung_capacity_lvl,['@strength_lvl'] = stats.strength_lvl}, nil)
	print("Stats: Saved stats of "..GetPlayerName(source))
	cachedStats[tonumber(source)] = nil
end)

RegisterServerEvent("stats:CacheStats")
AddEventHandler("stats:CacheStats", function(stats)
	cachedStats[tonumber(source)] = stats
end)

RegisterServerEvent("stats:saveAll")
AddEventHandler("stats:saveAll", function()
	local asyncTasks = {}
	if #cachedStats~=0 then
		for i=1,#cachedStats,1 do
			table.insert(asyncTasks, function()
				local stats = cachedStats[i]
				if stats==nil then return end
				MySQL.Sync.execute('UPDATE `stats` SET `stamina`=@stamina,`lung_capacity`=@lung_capacity,`strength`=@strength,`stamina_xp`=@stamina_xp,`lung_capacity_xp`=@lung_capacity_xp,`strength_xp`=@strength_xp,`stamina_lvl`=@stamina_lvl,`lung_capacity_lvl`=@lung_capacity_lvl,`strength_lvl`=@strength_lvl WHERE `identifier`=@identifier;', {['@identifier'] = tostring(Identifier), ['@stamina'] = stats.stamina, ['@lung_capacity'] = stats.lung_capacity, ['@strength'] = stats.strength, ['@stamina_xp'] = stats.stamina_xp,['@lung_capacity_xp'] = stats.lung_capacity_xp,['@strength_xp'] = stats.strength_xp,['@stamina_lvl'] = stats.stamina_lvl,['@lung_capacity_lvl'] = stats.lung_capacity_lvl,['@strength_lvl'] = stats.strength_lvl}, nil)	
			end)
		end
		Async.parallelLimit(asyncTasks, 8, function(results)
			print("Stats: Saved all players")
		end)
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(Config.StatsTimeSave)
		TriggerEvent("stats:saveAll")
	end
end)