***COMMANDS***
- /saveallstats -- saves stats for all players (admin command)
- /statset <stamina|lung_capacity|strength> <xp|lvl|> <value> -- set (admin command)
- /showstatsxp -- shows your XP hud
- /stats -- shows your stats

- when you run, you're getting stamina.
- when you go to the gym on the beach, you're getting strength
- when you swimm under the water, your lung capacity will increase