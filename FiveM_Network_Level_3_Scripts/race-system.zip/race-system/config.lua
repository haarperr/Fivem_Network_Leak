Config               = {}
Config.Locale        = 'en'

Config.JoinDistance = 25.0

