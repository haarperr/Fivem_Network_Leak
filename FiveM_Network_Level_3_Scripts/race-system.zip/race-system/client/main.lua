ESX = nil

local DrawCountdown = false
local Countdown = 3
local AnnounceString = false
local AnnounceHeader = false
local LastFor = 5
local Races = {}
local Racing = false
local RaceCreator = false
local RaceJoined = false
local Race = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function cd(num)
  SetTextCentre(true)
  SetTextFont(6)
  SetTextScale(2.0, 2.0)
  SetTextColour(0, 200, 255,255)
  SetTextDropShadow(0, 0, 0, 0, 255)
  SetTextEdge(2, 0, 0, 0, 255)
  SetTextDropShadow()
  SetTextOutline()
  SetTextEntry("STRING")
  AddTextComponentString(num)
  DrawText(0.5, 0.25)
end

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end

function Initialize(scaleform)
    local scaleform = RequestScaleformMovie(scaleform)
    while not HasScaleformMovieLoaded(scaleform) do
        Citizen.Wait(0)
    end
    PushScaleformMovieFunction(scaleform, "SHOW_SHARD_WASTED_MP_MESSAGE")
    PushScaleformMovieFunctionParameterString(AnnounceHeader)
    PushScaleformMovieFunctionParameterString(AnnounceString)
    PopScaleformMovieFunctionVoid()
    return scaleform
end

RegisterNetEvent("race:getWaypoint")
AddEventHandler("race:getWaypoint", function()
    local blip = GetFirstBlipInfoId(8)
    local ped = GetPlayerPed(-1)
    local veh = GetVehiclePedIsUsing(ped)
    print(IsVehicleSeatFree(veh, -1))
    if blip ~= 0 and veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
        local start = GetEntityCoords(veh)
        local coords = Citizen.InvokeNative(0xFA7C7F0AADF25D09, blip, Citizen.ResultAsVector())
        local x, y, z = table.unpack(coords)
        TriggerServerEvent("race:create", {x, y}, start)
    else
        TriggerServerEvent("race:create", false)
    end
end)

RegisterNetEvent("race:created")
AddEventHandler("race:created", function(creator, data)
    local ped = GetPlayerPed(-1)
    local veh = GetVehiclePedIsUsing(ped)
    Races[creator] = data

    if veh and creator == GetPlayerServerId(PlayerId()) then
        FreezeEntityPosition(veh, true)
        RaceCreator = true
        RaceJoined = true
        Race = data.creator
    else
        ESX.ShowNotification(_U('no_vehicle'))
    end
end)

RegisterNetEvent("race:result")
AddEventHandler("race:result", function(race, winner)
    if winner == GetPlayerServerId(PlayerId()) and Race == race then
        SetAudioFlag("LoadMPData", true)
        PlaySoundFrontend(-1, "RACE_PLACED", "HUD_AWARDS", 1)
        AnnounceHeader = "~g~Winner"
        AnnounceString = "+$" .. Races[race].entry*Races[race].max
        Races[race] = nil
        Race = false
        RaceJoined = false
        RaceCreator = false
        Citizen.Wait(LastFor * 1000)
        AnnounceString = false
    elseif Race == race then
        SetAudioFlag("LoadMPData", true)
        PlaySoundFrontend(-1, "LOSER", "HUD_AWARDS", 1)
        AnnounceHeader = "~r~Loser"
        AnnounceString = "-$" .. Races[race].entry
        Races[race] = nil
        Race = false
        RaceJoined = false
        RaceCreator = false
        Racing = false
        Citizen.Wait(LastFor * 1000)
        AnnounceString = false
    end
end)

RegisterNetEvent("race:end")
AddEventHandler("race:end", function(creator)
    local ped = GetPlayerPed(-1)
    local veh = GetVehiclePedIsUsing(ped)

    if veh then
        if RaceCreator and Race == creator then
            FreezeEntityPosition(veh, false)
            RaceCreator = false
            TriggerServerEvent("race:refund", Races[creator].entry)
            Races[creator] = nil
        elseif Race == creator then
            FreezeEntityPosition(veh, false)
            Race = false
            TriggerServerEvent("race:refund", Races[creator].entry)
            Races[creator] = nil
        end
    else
        -- end message
    end
end)

RegisterNetEvent("race:update")
AddEventHandler("race:update", function(race, data)
    Races[race] = data
end)

RegisterNetEvent("race:start")
AddEventHandler("race:start", function(race)
    local ped = GetPlayerPed(-1)
    local veh = GetVehiclePedIsUsing(ped)
    RaceCreator = false
    RaceJoined = false

    if Race == race then
        DrawCountdown = true

        SetAudioFlag("LoadMPData", true)
        Countdown = 3
        PlaySoundFrontend(-1, "3_2_1", "HUD_MINI_GAME_SOUNDSET", 1)
        Wait(1000)
        Countdown = 2
        PlaySoundFrontend(-1, "3_2_1", "HUD_MINI_GAME_SOUNDSET", 1)
        Wait(1000)
        Countdown = 1
        PlaySoundFrontend(-1, "3_2_1", "HUD_MINI_GAME_SOUNDSET", 1)
        Wait(600)
        PlaySoundFrontend(-1, "GO", "HUD_MINI_GAME_SOUNDSET", 1)
        Wait(400)
        Countdown = "GO"
        Racing = Races[race]
        FreezeEntityPosition(veh, false)
        SetNewWaypoint(Races[race].waypoint[1], Races[race].waypoint[2])
        StartScreenEffect("RaceTurbo", 750, false)
        Wait(1000)
        DrawCountdown = false
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)
        local ped = GetPlayerPed(-1)
        local veh = GetVehiclePedIsUsing(ped)
        local coords = GetEntityCoords(ped)

        if DrawCountdown then
            cd(tostring(Countdown))
        end

        if RaceCreator and not Racing and Race then
            DrawText3Ds(coords.x, coords.y, coords.z, "Wait for other players")
        end

        if Racing then
            DrawText3Ds(Racing.waypoint[1], Racing.waypoint[2], 50, "Finish")

            if GetDistanceBetweenCoords(coords, Racing.waypoint[1], Racing.waypoint[2], 50) < 50 then
                TriggerServerEvent("race:win", Racing.creator)
                Racing = false
            end
        end

        for i,v in pairs(Races) do
            if Race and not Racing and not RaceCreator and veh and  GetPedInVehicleSeat(veh, -1) == ped then
                DrawText3Ds(coords.x, coords.y, coords.z, "Leave the race [~g~E~w~]")
                if IsControlPressed(0, 38) then
                    ESX.TriggerServerCallback('race:leave', function(success)
                        if success then
                            Race = false
                            Races[i].joined = Races[i].joined -1
                            RaceJoined = false
                            FreezeEntityPosition(GetVehiclePedIsUsing(GetPlayerPed(-1)), false)
                        end
                    end, i)
                    Wait(150)
                end
            elseif v.joined < v.max and not RaceCreator and not Racing and not Race and veh and  GetPedInVehicleSeat(veh, -1) == ped then
                local coords = GetEntityCoords(GetPlayerPed(-1))
                if GetDistanceBetweenCoords(coords, v.start.x, v.start.y, v.start.z, true) < Config.JoinDistance then
                    DrawText3Ds(coords.x, coords.y, coords.z, "Join the race [~g~E~w~]")
                    if IsControlPressed(0, 38) then
                        ESX.TriggerServerCallback('race:join', function(success)
                            if success then
                                Race = v.creator
                                Races[i].joined = Races[i].joined + 1
                                RaceJoined = true
                                FreezeEntityPosition(veh, true)
                            end
                        end, i)
                        Wait(150)
                    end
                end
            end
        end

    end
end)

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    if AnnounceString then
      scaleform = Initialize("mp_big_message_freemode")
      DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 255, 0)
    end
  end
end)