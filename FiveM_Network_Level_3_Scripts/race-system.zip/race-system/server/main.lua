ESX = nil

local Races = {}

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

TriggerEvent('es:addCommand', 'race', function(source, args, user)
	local xPlayer = ESX.GetPlayerFromId(source)

	if args[1] and args[2] then
		if not Races[source] then
			Races[source] = {max = tonumber(args[1]), joined = 1, entry = tonumber(args[2]), creator = source}
		end
		TriggerClientEvent("race:getWaypoint", source)
	end
		
end, {help = "Start a race with this command", params = {{name = "race", help = "/race"}}})

TriggerEvent('es:addCommand', 'endrace', function(source, args, user)
	local xPlayer = ESX.GetPlayerFromId(source)

	if Races[source] then
		Races[source] = nil
	end

	TriggerClientEvent("race:end", -1, source)
		
end, {help = "End race", params = {{name = "endrace", help = "/endrace"}}})

RegisterServerEvent("race:create")
AddEventHandler("race:create", function(finish, start)
	local xPlayer = ESX.GetPlayerFromId(source)

	if not finish then
		Races[source] = nil
		TriggerClientEvent('esx:showNotification', source, _U('no_waypoint'))
	elseif xPlayer.getMoney() < Races[source].entry then
		Races[source] = nil
		TriggerClientEvent('esx:showNotification', source, _U('not_enough'))
	else
		Races[source].waypoint = finish
		Races[source].start = start

		xPlayer.removeMoney(Races[source].entry)
		TriggerClientEvent("race:created", -1, source, Races[source])
	end
end)

RegisterServerEvent("race:win")
AddEventHandler("race:win", function(race)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addMoney(Races[race].entry*Races[race].max)
	Races[race] = nil
	TriggerClientEvent("race:result", -1, race, source)
end)

RegisterServerEvent("race:refund")
AddEventHandler("race:refund", function(amount)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.addMoney(amount)
end)

ESX.RegisterServerCallback('race:join', function(source, cb, race)
	local xPlayer = ESX.GetPlayerFromId(source)

	if xPlayer.getMoney() > Races[race].entry and Races[race].joined < Races[race].max then
		xPlayer.removeMoney(Races[race].entry)
		Races[race].joined = Races[race].joined +1

		TriggerClientEvent("race:update", -1, race, Races[race])
		cb(true)
		if Races[race].joined == Races[race].max then
			TriggerClientEvent("race:start", -1, race)
		end
	else
		TriggerClientEvent('esx:showNotification', source, _U('not_enough'))
	end
end)

ESX.RegisterServerCallback('race:leave', function(source, cb, race)
	local xPlayer = ESX.GetPlayerFromId(source)

	if Races[race].joined ~= Races[race].max then
		xPlayer.addMoney(Races[race].entry)
		Races[race].joined = Races[race].joined - 1
		cb(true)
	end
end)