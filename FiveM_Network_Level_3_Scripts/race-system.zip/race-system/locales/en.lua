Locales['en'] = {
	['no_waypoint'] = "You have to set a waypoint!",
	['not_enough'] = "You don't have enough money!",
	['not_vehicle'] = "You have to be in vehicle for starting the race!"
}
