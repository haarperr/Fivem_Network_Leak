FEATURES:
- Can buy weapons + components at ammunation shop near car dealer (you can change it but you can only have 1 shop at the moment)

REQUIREMENTS:
- ESX

INSTALLATION:
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_weaponshop

CREDITS:
- Elipse458
- Warxander (https://forum.fivem.net/t/release-0-9-8-final-warmenu-lua-menu-framework/41249)