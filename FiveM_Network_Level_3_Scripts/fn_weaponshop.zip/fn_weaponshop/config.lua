Config = {}
Config.price_format = "~r~$%d" -- %d <- price
Config.cam_coords = vector3(21.988, -1107.593, 30.426)
Config.cam_point_coords = vector3(22.549, -1106.119, 29.789) -- placeholder <- the camera will point at the floating weapon once it spawns
Config.weapon_coords = vector3(22.549, -1106.119, 30.0) -- the floating weapon coords
Config.marker = {
    pos = vector3(21.86, -1106.684, 28.797),
    size = vector3(1,1,0.2),
    color = {r = 247, g = 65, b = 71, a = 150}
}
Config.lang = {
    owned = "Owned",
    equipped = "Equipped",
    yes = "Yes",
    no = "No",
    back = "Back",
    attachments_upgrades = "Attachments/Upgrades",
    tints = "Tints",
    free = "Free",
    ammo = "Ammo (%d)", -- %d <- ammo count
    not_enough_money = "~r~Not enough money!",
    marker_text = "Press ~INPUT_CONTEXT~ to shop for guns"
}
Config.menu = {
    main = {
        title = "AMMU-NATION",
        subtitle = "Available weapons",
        x = 0.76,
        y = 0.25,
        titlecolor = {255,255,255,255}, -- r,g,b,a
        backcolor = {247,65,71,255} -- r,g,b,a
    },
    weapon = {
        title = "%s", -- %s <- weapon label
        subtitle = "Available upgrades", -- %s <- weapon label
        x = 0.76,
        y = 0.25,
        titlecolor = {255,255,255,255}, -- r,g,b,a
        backcolor = {247,65,71,255} -- r,g,b,a
    }
}
--[[

Add your own weapons:
https://www.se7ensins.com/forums/threads/weapon-and-explosion-hashes-list.1045035/
https://wiki.rage.mp/index.php?title=Weapons_Components
https://wiki.gtanet.work/index.php?title=Weapons_Tints

--]]
Config.weapons = {
    {
        weapon = "WEAPON_PISTOL",
        label = "Pistol",
        price = 1000,
        can_buy_ammo = true,
        ammo_price = 150,
        ammo_count = 70,
        upgrades = {
            {
                label = "Flashlight",
                hash = "COMPONENT_AT_PI_FLSH",
                price = 45
            },
            {
                label = "Suppressor",
                hash = "COMPONENT_AT_PI_SUPP_02",
                price = 75
            }
        },
        tints = {
            {
                label = "Default tint",
                index = 0,
                price = 0
            },
            {
                label = "Gold tint",
                index = 2,
                price = 75
            },
            {
                label = "Platinum tint",
                index = 7,
                price = 95
            }
        }
    },
    {
        weapon = "WEAPON_CARBINERIFLE",
        label = "Carabine Rifle",
        price = 1000,
        can_buy_ammo = true,
        ammo_price = 250,
        ammo_count = 70,
        upgrades = {
            {
                label = "Flashlight",
                hash = "COMPONENT_AT_AR_FLSH",
                price = 45
            }
        },
        tints = {
            {
                label = "Default tint",
                index = 0,
                price = 0
            },
            {
                label = "Gold tint",
                index = 2,
                price = 75
            },
            {
                label = "Pink tint",
                index = 3,
                price = 75
            }
        }
    },
    {
        weapon = "WEAPON_RPG",
        label = "RPG",
        price = 1000,
        can_buy_ammo = false,
        ammo_price = 0,
        ammo_count = 0
    },
    {
        weapon = "WEAPON_ASSAULTRIFLE",
        label = "Assault Rifle",
        price = 1000,
        can_buy_ammo = false,
        ammo_price = 0,
        ammo_count = 0,
    },
    {
        weapon = "WEAPON_RAILGUN",
        label = "Railgun",
        price = 1000,
        can_buy_ammo = false,
        ammo_price = 0,
        ammo_count = 0,
        tints = {
            {
                label = "Pink",
                index = 3,
                price = 1337
            }
        }
    }
}