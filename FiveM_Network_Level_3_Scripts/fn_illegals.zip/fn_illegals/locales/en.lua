Locales['en'] = {
    ["marker_do_txt"] = "Press ~INPUT_TALK~ to store illegals",
    ["not_items_notify"] = "You dont have any illegal items",
    ["dialog_title"] = "How much ?",
    ["amount_invalid"] = "Invalid amount",
}