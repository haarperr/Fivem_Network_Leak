Locales['cs'] = {
    ["marker_do_txt"] = "Stiskni ~INPUT_TALK~ pro odevzdani latek",
    ["not_items_notify"] = "Nemas zadne nelegalni predmety",
    ["dialog_title"] = "Kolik ?",
    ["amount_invalid"] = "Neplatná castka",
}