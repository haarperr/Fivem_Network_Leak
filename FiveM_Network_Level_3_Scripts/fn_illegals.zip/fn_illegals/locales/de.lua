Locales['de'] = {
    ["marker_do_txt"] = "Drücken Sie ~INPUT_TALK~, um Stoffe auszuhändigen",
    ["not_items_notify"] = "Sie haben keine illegalen Gegenstände",
    ["dialog_title"] = "Wie viel ?",
    ["amount_invalid"] = "ungültige Menge",
}