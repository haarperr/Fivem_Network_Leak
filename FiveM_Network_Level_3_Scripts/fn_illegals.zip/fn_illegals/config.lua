Config = {}
 
Config.MarkerColor = {r = 0, g = 200, b = 204}
Config.JobName = "police" -- required  job
Config.Bonus = 800 -- money bonus

Config.CountMoney = 500
Config.BonusMoney = 200

Config.Items = {"weed", "coke", "meth", "opium"} -- List of the illegal items (do not add weapons!)

Config.Zones = { 
    {type = 27, x = 437.3708, y = -986.0275, z = 29.6896} -- script zones
}

Config.Locale = "en" 