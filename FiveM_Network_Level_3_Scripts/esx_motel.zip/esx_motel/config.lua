Config                        = {}
Config.DrawDistance           = 10
Config.MarkerSize             = {x = 1.5, y = 1.5, z = 1.0}
Config.MarkerColor            = {r = 102, g = 102, b = 204}
Config.RoomMenuMarkerColor    = {r = 102, g = 204, b = 102}
Config.MarkerType             = 27
Config.Zones                  = {}
Config.Motells             = {}
Config.EnablePlayerManagement = false -- If set to true you need esx_realestateagentjob
Config.Locale                 = 'en'
Config.Motels = {
	{name = "Perrera Beach Motel", x = -1471.856, y = -659.7877, sprite = 475, color = 1}
}
