FEATURES:
- Allows you to replace a vanilla GTA 5 radio station with your own
- You can have people reporting news on your radio and playing songs

REQUIREMENTS:
- None

INSTALLATION:
- Ask Elipse458#1337 for web radio credentials
- Change the mount point (first line) in html/script.js
- Change the radio station you want to replace (first line) in client.lua
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_radio_job

STREAM SETUP:
- Download MIXXX (https://www.mixxx.org/)
- Download libmp3lame zip and put libmp3lame.dll from the zip into C:\Program Files\Mixxx (https://lame.buanzo.org/#lamewindl)
- Setup your live broadcasting in settings of MIXXX (https://i.elipse458.me/a86a19d)
- Enable live boarcasting and you should be streaming to the radio (https://i.elipse458.me/8b0cf03)
- OPTIONAL - if you want to use your microphone in the stream, setup your mic in the settings (https://i.elipse458.me/991755e)

CREDITS:
- Elipse458
