Config:
Shops -> cash_registers -> [{x,y,z,w}]
                                   ^
                                   This is heading
Everything else is self explanatory

https://www.json.org/
https://jsonformatter.curiousconcept.com/