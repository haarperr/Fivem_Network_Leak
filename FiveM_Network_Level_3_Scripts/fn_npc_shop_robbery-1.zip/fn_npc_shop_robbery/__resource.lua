resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

files {
    "config.json"
}

client_script "Fn_Npc_Shop_Robbery_Client.net.dll"
server_script "Fn_Npc_Shop_Robbery_Server.net.dll"
-- server_script "server.lua"