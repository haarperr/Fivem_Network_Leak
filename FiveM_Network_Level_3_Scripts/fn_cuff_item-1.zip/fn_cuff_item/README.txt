FEATURES:
- Cuff people with the "cuffs" item
- Uncuff people with the "cuffs" item if they're already 

REQUIREMENTS:
- ESX

INSTALLATION:
- Import sql.sql in your database
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_cuff_item

CREDITS:
- Elipse458