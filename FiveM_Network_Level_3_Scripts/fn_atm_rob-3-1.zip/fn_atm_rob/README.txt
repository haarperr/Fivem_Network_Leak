FEATURES:
- Rob ATMs at defined points

REQUIREMENTS:
- ESX

INSTALLATION:
- Put the resource in your resources directory
- Edit the config.lua file
- Add this in your server.cfg
   start fn_atm_robbery

CREDITS:
- Elipse458
