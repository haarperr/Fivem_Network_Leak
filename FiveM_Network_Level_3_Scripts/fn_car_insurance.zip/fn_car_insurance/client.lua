if not __CONFIG then return end
ESX = nil
local menu,insurance_plates,insurance_vehicles = false,{},{}

function getInsurances()
	ESX.TriggerServerCallback("fn_vehicle_insurance:getInsurances",function(insurances)
		for k,v in ipairs(insurances) do table.insert(insurance_plates,v.plate) end
	end)
end

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent("fn_vehicle_insurance:getInsurances")
AddEventHandler("fn_vehicle_insurance:getInsurances", function() getInsurances() end)

local function rtrim(s) if not s then return "" end; return s:gsub("%s*$", "") end

Citizen.CreateThread(function()
	local blip = AddBlipForCoord(__CONFIG.blip.pos)
	SetBlipSprite (blip, __CONFIG.blip.sprite)
	SetBlipDisplay(blip, 4)
	SetBlipScale  (blip, 1.0)
	SetBlipAsShortRange(blip, true)

	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString(__CONFIG.blip.text)
	EndTextCommandSetBlipName(blip)
	local lastveh = nil
	while true do
		Citizen.Wait(100)
		local ped = GetPlayerPed(-1)
		local veh = GetVehiclePedIsIn(ped, false)
		if DoesEntityExist(veh) then
			local plate = rtrim(GetVehicleNumberPlateText(veh))
			if ESX.TableContainsValue(insurance_plates, plate) and not (function() for k,v in ipairs(insurance_vehicles) do if v.plate==plate then return true end end; return false end)() then table.insert(insurance_vehicles,{veh=veh,plate=plate}) end
		end
		lastveh=veh
		for k,v in ipairs(insurance_vehicles) do
			if not DoesEntityExist(v.veh) or IsEntityDead(v.veh) then
				Citizen.CreateThread(function()
					Citizen.Wait(250)
					ESX.TriggerServerCallback("fn_vehicle_insurance:isVehInGarage",function(ingarage)
						if not ingarage then
							ESX.ShowNotification(__CONFIG.lang.vehicle_destroyed:format(DoesEntityExist(v.veh) and __CONFIG.lang.vehicle_destroyed_broken or __CONFIG.lang.vehicle_destroyed_despawned))
							TriggerServerEvent("fn_vehicle_insurance:carDestroyed", v.plate)
						end
					end,v.plate)
				end)
				table.remove(insurance_vehicles,k)
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local pp = GetEntityCoords(GetPlayerPed(-1))
		if GetDistanceBetweenCoords(pp, __CONFIG.marker.pos, false)<__CONFIG.marker.draw_distance then
			DrawMarker(1, __CONFIG.marker.pos, 0, 0, 0, 0, 0, 0, __CONFIG.marker.size.x, __CONFIG.marker.size.y, __CONFIG.marker.size.z, __CONFIG.marker.color.r, __CONFIG.marker.color.g, __CONFIG.marker.color.b, __CONFIG.marker.color.a, 0, 0, 0, false)
			if GetDistanceBetweenCoords(pp, __CONFIG.marker.pos, false)<__CONFIG.marker.size.x and not menu then
				ESX.ShowHelpNotification(__CONFIG.marker.help_text)
				if IsControlJustPressed(0, 51) then
					ESX.TriggerServerCallback("fn_vehicle_insurance:getInsurancePrices",function(prices)
						if not prices or #prices<=0 then ESX.ShowNotification(__CONFIG.lang.no_cars); return end
						local elements = {}
						for k,v in ipairs(prices) do table.insert(elements,{label=__CONFIG.menu.button_format:format(GetDisplayNameFromVehicleModel(v.model),v.destroyed and __CONFIG.menu.veh_destroyed or (v.insured and __CONFIG.menu.already_insured or (v.price and __CONFIG.menu.price_format:format(v.price) or __CONFIG.menu.price_not_found))),key=k,plate=v.plate,value=(v.price and not v.insured and not v.destroyed) and "insurance" or (v.destroyed and "destroyed" or nil)}) end
						ESX.UI.Menu.CloseAll()
						menu = true
						ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'buy_insurance',
						{
							title = __CONFIG.menu.title,
							align = 'bottom-right',
							elements = elements
						}, function(data, menu)
							if data.current.value == "insurance" then
								ESX.TriggerServerCallback("fn_vehicle_insurance:buyInsurance",function(canbuy)
									if canbuy then
										menu.setElement(data.current.key, "label", __CONFIG.menu.button_format:format(GetDisplayNameFromVehicleModel(prices[data.current.key].model),__CONFIG.menu.already_insured));menu.setElement(data.current.key, "value", nil);menu.refresh()
										table.insert(insurance_plates,data.current.plate)
										ESX.ShowNotification(__CONFIG.lang.insurance_bought)
									else
										ESX.ShowNotification(__CONFIG.lang.not_enough_money)
									end
								end,data.current.plate)
							elseif data.current.value == "destroyed" then
								TriggerServerEvent("fn_vehicle_insurance:retrieveInsuredVehicle",data.current.plate)
								menu.setElement(data.current.key, "label", __CONFIG.menu.button_format:format(GetDisplayNameFromVehicleModel(prices[data.current.key].model),__CONFIG.menu.already_insured));menu.setElement(data.current.key, "value", nil);menu.refresh()
							end
						end, function(data, menu)
							menu.close()
						end)
					end)
				end
			elseif GetDistanceBetweenCoords(pp, __CONFIG.marker.pos, false)>__CONFIG.marker.size.x and menu then
				ESX.UI.Menu.Close("default",GetCurrentResourceName(),"buy_insurance");menu=false
			end
		end
	end
end)

RegisterNetEvent("fn_vehicle_insurance:respawnVehicle")
AddEventHandler("fn_vehicle_insurance:respawnVehicle",function(vehicle)
	ESX.Game.SpawnVehicle(vehicle.model, __CONFIG.car_respawn.point_pos, __CONFIG.car_respawn.point_heading, function(callback_vehicle)
		ESX.Game.SetVehicleProperties(callback_vehicle, vehicle)
		SetVehicleNumberPlateText(callback_vehicle, vehicle.plate)
		table.insert(insurance_vehicles,{veh=callback_vehicle,plate=vehicle.plate})
	end)
end)