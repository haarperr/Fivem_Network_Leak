__CONFIG = {}
--[[
    This should be pretty much good to go out right of the box, just change the positions and you're good to go
--]]


__CONFIG.car_respawn = {
    use_point = false, -- if set to false the car will be put into garage
    point_pos = vector3(-1834.41, -3151.056, 13.0),
    point_heading = 0.0,
    time = 600 -- time it takes to claim a new vehicle from the insurance (in seconds) || set to 0 to disable
}

__CONFIG.marker = {
    pos = vector3(-1834.41, -3149.056, 13.0),
    size = vector3(1,1,0.3),
    color = {r = 255, g = 255, b = 255, a = 100},
    draw_distance = 30.0,
    help_text = "Press ~INPUT_CONTEXT~ to check your insurances"
}

__CONFIG.blip = {
    pos = vector3(-1834.41, -3149.056, 13.0),
    sprite = 493,
    text = "Vehicle Insurance"
}

__CONFIG.menu = {
    title = "Insurances",
    price_format = "<span style='color:green;'>$%d</span>",
    price_not_found = "<span style='color:red;'>Insurance N/A</span>",
    already_insured = "<span style='color:green;'>Insured</span>",
    veh_destroyed = "<span style='color:red;'>Destroyed</span>",
    button_format = "%s %s" -- %s <-- car name | 2nd %s <-- price 
}

__CONFIG.price = {
    percentage = true, -- set to false to be a fixed price
    value = 35
}

__CONFIG.lang = {
    no_insurance_for_this_veh = "~r~There's no insurance available for this car",
    not_enough_money = "~r~You don't have enough money",
    insurance_bought = "~g~Your car is now insured",
    no_cars = "~r~No cars to insure",
    already_insured = "~r~This car is already insured",
    time_format = "~b~%02d~s~m ~b~%02d~s~s", -- only touch if u know what you're doing, i'm not explaining this
    car_respawn = "Your car will arrive in your garage in ~b~%s", -- %s <-- time || make it not say garage when you're not respawning it in garage
    car_respawned = "Your car has arrived in your garage", -- again, make it say something else ig you're not respawning in garage and this only shows up if respawn time > 0
    vehicle_destroyed_broken = "been destroyed",
    vehicle_destroyed_despawned = "despawned", -- you can make this say "stolen" or something to make it more RP-esk
    vehicle_destroyed = "Your vehicle has %s" -- one of the 2 above
}

__CONFIG.garage_vehicle_list = { -- you probably don't need to change / add to this but if you do then heres an explanation -> get owned vehicle data (vehicle is esx vehicle properties)
    "SELECT vehicle AS vehicle FROM owned_vehicles WHERE owner=@owner"
}

__CONFIG.garage_vehicle_from_plate = { -- you probably don't need to change / add to this but if you do then heres an explanation -> get owned vehicle data from plate (vehicle is esx vehicle properties)
    "SELECT vehicle AS vehicle FROM owned_vehicles WHERE owner=@owner AND plate=@plate"
}

__CONFIG.garage_set_stored = { -- you probably don't need to change / add to this but if you do then heres an explanation -> set vehicle with plate as stored in garage
    "UPDATE owned_vehicles SET state=1 WHERE plate=@plate AND owner=@owner"
}

__CONFIG.garage_get_stored = { -- you probably don't need to change / add to this but if you do then heres an explanation -> get stored state of vehicle with plate
    "SELECT state AS state FROM owned_vehicles WHERE plate=@plate and owner=@owner"
}

__CONFIG.vehicle_prices = {
    mysql = {
        enabled = true,
        queries = { -- basically select the model and price from the table (AS ... - makes the selected column be accesible from script as ... (it works, dont question it))
            -- EXAMPLE WITH DIFFERENT STRUCTURE: "SELECT mmooddeell AS model, cost AS price FROM another_vehicles_table",
            "SELECT model AS model, price AS price FROM vehicles"
        }
    },
    file = { -- will override mysql
        enabled = true,
        files = {
            --[[ EXAMPLE WITH DIFFERENT STRUCTURE:
            {resource="my_pretty_resource",file="prices.lua",iterator=function()
                -- if your table already has the format {model_name=price} then just return it (return my_prices_table)
                -- if not then make a local table and make it that format
                local prices = {} -- make sure you don't override the imported variable if it's the same name
                for k,v in ipairs(my_prices_table) do
                    -- lets say the format of your table is like this: {{model=xxx, ..., value=xxx},{model=xxx, ..., value=xxx}}
                    prices[v.model]=v.value
                end
                return prices
            end, cleanup = function()
                my_prices_table = nil
                -- if you have any other variables in that file, clean those too
            end},
            --]]
            {resource="fn_vehicleshop",file="config.lua",iterator=function() -- fancy file loading for advanced users / needs format {somecar=1337,anothercar=12345,...}
                local prices = {}
                for k,v in ipairs(Config.cars) do
                    prices[v.model]=v.price
                end
                return prices
            end, cleanup = function() -- not required but it's nice to clean up the unnecessary stuff to free up ram
                Config = nil
            end}
        }
    },
    manual = { -- this will override the prices, even if they were found in files/mysql | leave empty or set to nil to disable
        --['prototipo'] = 1337,
        --['oppressor'] = 12345
    }
}