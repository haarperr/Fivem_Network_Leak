FEATURES:
- Auto SQL management - no need to do anything with the database, the plugin's got it
- A lot of configuration in the config file
- Buy car insurance with a set price subtracted from original car price or a percentage from original car price
- With default config it almost has a GTA:O vibe to it

REQUIREMENTS:
- ESX
- Any garage system you could imagine (if you configure it, default is esx_jb_eden_garage or esx_drp_garage)

INSTALLATION:
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_car_insurance

CREDITS:
- Elipse458