Locales['en'] = {
	['missing_item'] = "You are out of %s!",
	['sold'] = "You have sold %s for $%s",
}
