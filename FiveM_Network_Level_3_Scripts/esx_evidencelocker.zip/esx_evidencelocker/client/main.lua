local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}

local PlayerData                = {}
ESX = nil
local MenuOpened = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
	end

    Citizen.Wait(5000)
    PlayerData = ESX.GetPlayerData()
end)

function OpenLocker()
    local elements = {}
    local elements2 = {}

    ESX.TriggerServerCallback('esx_evidencelocker:getInventory', function(result)

        table.insert(elements, {label = "Deposit", value = "deposit"})

        for i=1, #result.items, 1 do
        
            local invitem = result.items[i]
      
            if invitem.count > 0 then
                table.insert(elements2, { label = invitem.label .. ' | ' .. invitem.count .. ' in your bag', type = "item_standard", count = invitem.count, value = invitem.name})
            end
        end

        if result.money > 0 then
            table.insert(elements2, { label = 'Money:'.. result.money, type = "item_account", value = result.money})
        end
        
        local invitem = result.accounts
        if invitem.money > 0 then
            table.insert(elements, { label = 'Money:'.. invitem.money, type = "item_account", value = invitem.money})
        end

        for i=1, #result.loadout, 1 do
            local weapon = result.loadout[i]

            table.insert(elements2, {
                label = ESX.GetWeaponLabel(weapon.name) .. ' [' .. weapon.ammo .. ']',
                type  = 'item_weapon',
                value = weapon.name,
                ammo  = weapon.ammo
            })
        end

        for i=1, #result.locker, 1 do
        
            local invitem = result.locker[i]
      
            if invitem.count > 0 and invitem.label ~= nil then
                table.insert(elements, { label = invitem.label .. ' | ' .. invitem.count .. ' in your bag',
                type = 'item_standard',
                count = invitem.count,
                value = invitem.name})
            end
        end

        for i=1, #result.weapons, 1 do
            local weapon = result.weapons[i]

            table.insert(elements, {
                label = ESX.GetWeaponLabel(weapon.name) .. ' [' .. weapon.ammo .. ']',
                type  = 'item_weapon',
                value = weapon.name,
                count  = weapon.ammo
            })
        end

        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'locker_room', {title= "Locker Room", align = 'top-left', elements=elements},
            function(data, menu)
                if data.current.value == "deposit" then
                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'locker_deposit', {title= "Items", align = 'top-left', elements=elements2},
                        function(data2, menu2)
                            if data2.current.type then
                                ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'sell', {
                                    title = "How much ?"
                                }, function(data3, menu3)

                                    local count = tonumber(data3.value)
                                    local itemName = data2.current.value
                                    local invcount = data2.current.count
        
                                    if data2.current.type == "item_standard" and invcount ~= nil and count > invcount then
                                        ESX.ShowNotification('~r~You can\'t sell more than you own')
                                        menu3.close()
                                        menu2.close()
                                        menu.close()
                                    elseif data2.current.type == "item_account" and itemName >= count then
                                        menu3.close()
                                        menu2.close()
                                        menu.close()
                                        TriggerServerEvent('esx_evidencelocker:depositEvidence', data2.current.type, itemName, count)
                                    else
                                        menu3.close()
                                        menu2.close()
                                        menu.close()
                                        TriggerServerEvent('esx_evidencelocker:depositEvidence', data2.current.type, itemName, count)
                                    end

                                end, 
                                function(data3, menu3)
                                    menu3.close()
                                end)
                            end
                        end, function(data2, menu2)
                        menu2.close()
                    end)
                else
                    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'withdraw', {
                        title = "How much ?"
                    }, function(data2, menu2)

                        local count = tonumber(data2.value)
                        local itemName = data.current.value
                        local invcount = data.current.count

                        if invcount ~= nil and count > invcount then
                            ESX.ShowNotification('~r~You can\'t sell more than you own')
                            menu2.close()
                            menu.close()
                        elseif data.current.type == "item_account" and itemName >= count then
                            menu2.close()
                            menu.close()
                            TriggerServerEvent('esx_evidencelocker:withdrawEvidence', data.current.type, itemName, count)
                        else
                            menu2.close()
                            menu.close()
                            TriggerServerEvent('esx_evidencelocker:withdrawEvidence', data.current.type, itemName, count)
                        end

                    end, 
                    function(data2, menu2)
                        menu2.close()
                    end)
                end
            end,function(data, menu) menu.close() 
        end)
    end)

end

Citizen.CreateThread(function()
    while true do
        Wait(0)

        local coords = GetEntityCoords(GetPlayerPed(-1))

        for i,v in ipairs(Config.Locations) do
            if GetDistanceBetweenCoords(coords, v.x, v.y, v.z, true) < Config.DrawDistance and PlayerData.job ~= nil and PlayerData.job.name == "police" then
                DrawMarker(1, v.x, v.y, v.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 2.0, 2.0, 1.0, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                if GetDistanceBetweenCoords(coords, v.x, v.y, v.z, true) < 3.0 then
                    ESX.ShowHelpNotification("Press ~INPUT_PICKUP~ to open evindence locker")
                    if IsControlJustReleased(0, 38) then
                        OpenLocker()
                    end
                end
            end
        end
    end
end)