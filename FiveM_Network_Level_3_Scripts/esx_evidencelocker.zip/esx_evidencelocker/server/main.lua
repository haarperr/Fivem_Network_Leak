ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterServerCallback('esx_evidencelocker:getInventory', function(source, cb)
  local xPlayer = ESX.GetPlayerFromId(source)
  local items   = xPlayer.inventory
  local money   = xPlayer.getMoney()
  local loadout = xPlayer.getLoadout()
  local accounts =  nil
  local locker  = nil
  local weapons = nil

  	TriggerEvent('esx_addoninventory:getSharedInventory', 'evidence_locker', function(inventory)
		locker = inventory.items
	end)

	TriggerEvent('esx_addonaccount:getSharedAccount', 'evidence_locker', function(account)
		accounts = account
	end)

	TriggerEvent('esx_datastore:getSharedDataStore', 'evidence_locker', function(store)
		weapons = store.get('weapons') or {}
	end)

  cb({items = items, money = money, accounts = accounts, loadout = loadout, locker = locker, weapons = weapons})

end)

RegisterServerEvent('esx_evidencelocker:depositEvidence')
AddEventHandler('esx_evidencelocker:depositEvidence', function(type, item, count)
	local xPlayer = ESX.GetPlayerFromId(source)
	local GetItem = xPlayer.getInventoryItem(Item)
	local sourceItem = xPlayer.getInventoryItem(item)

	if type == "item_standard" then
  		TriggerEvent('esx_addoninventory:getSharedInventory', 'evidence_locker', function(inventory)
			local inventoryItem = inventory.getItem(item)

			-- is there enough in the property?
			if count > 0 then
				inventory.addItem(item, count)
				xPlayer.removeInventoryItem(item, count)
			else
				TriggerClientEvent('esx:showNotification', _source, "Invalid Quantity")
			end
		end)
  	elseif type == "item_account" then
  		TriggerEvent('esx_addonaccount:getSharedAccount', 'evidence_locker', function(account)
			local roomAccountMoney = account.money

			if count > 0 then
				account.addMoney(count)
				xPlayer.removeMoney(count)
			else
				TriggerClientEvent('esx:showNotification', _source, _U('amount_invalid'))
			end
		end)
  	elseif type == "item_weapon" then
  		TriggerEvent('esx_datastore:getSharedDataStore', 'evidence_locker', function(store)
			local storeWeapons = store.get('weapons') or {}

			table.insert(storeWeapons, {
				name = item,
				ammo = count
			})

			store.set('weapons', storeWeapons)
			xPlayer.removeWeapon(item, count)
		end)
	end
end)

RegisterServerEvent('esx_evidencelocker:withdrawEvidence')
AddEventHandler('esx_evidencelocker:withdrawEvidence', function(type, item, count)
  	local xPlayer = ESX.GetPlayerFromId(source)
 	local GetItem = xPlayer.getInventoryItem(Item)
  	local sourceItem = xPlayer.getInventoryItem(item)

	if type == "item_standard" then
		TriggerEvent('esx_addoninventory:getSharedInventory', 'evidence_locker', function(inventory)
			local inventoryItem = inventory.getItem(item)

			if count > 0 then
				inventory.removeItem(item, count)
				xPlayer.addInventoryItem(item, count)
			else
				TriggerClientEvent('esx:showNotification', _source, "Invalid Quantity")
			end
		end)
	elseif type == "item_account" then
		TriggerEvent('esx_addonaccount:getSharedAccount', 'evidence_locker', function(account)
			local roomAccountMoney = account.money

			if roomAccountMoney >= count then
				account.removeMoney(count)
				xPlayer.addMoney(count)
			else
				TriggerClientEvent('esx:showNotification', _source, _U('amount_invalid'))
			end
		end)
	elseif type == "item_weapon" then
		TriggerEvent('esx_datastore:getSharedDataStore', 'evidence_locker', function(store)
			local storeWeapons = store.get('weapons') or {}
			local weaponName   = nil
			local ammo         = nil

			for i=1, #storeWeapons, 1 do
				if storeWeapons[i].name == item then
					weaponName = storeWeapons[i].name
					ammo       = storeWeapons[i].ammo

					table.remove(storeWeapons, i)
					break
				end
			end
			print("weapon added")
			store.set('weapons', storeWeapons)
			xPlayer.addWeapon(weaponName, ammo)
		end)
	end
end)