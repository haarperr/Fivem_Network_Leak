Config               = {}
Config.Locale        = 'en'

Config.DrawDistance = 100.0
Config.MarkerColor  = {r = 300, g = 104, b = 100}

Config.Locations = {
	{x= 452.5092, y = -979.9543, z = 29.68959}
}