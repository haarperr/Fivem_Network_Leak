USE `essentialmode`;

INSERT INTO `addon_account`(`name`, `label`, `shared`) VALUES ('evidence_locker', 'Evidence Locker', 1);

INSERT INTO `addon_inventory`(`name`, `label`, `shared`) VALUES ('evidence_locker', 'Evidence Locker', 1);

INSERT INTO `datastore`(`name`, `label`, `shared`) VALUES ('evidence_locker', 'Evidence Locker', 1);