var Config = {
    appName: "Tuner 2000",
    monitorBrand: "FIVEM NETWORK"
};