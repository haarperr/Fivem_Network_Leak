ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function OpenParameterDialog(length,text)
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP", "", text~=nil and text or "", "", "", "", length)
    while UpdateOnscreenKeyboard()==0 do
        DisableAllControlActions(0)
        Wait(0)
    end
    if GetOnscreenKeyboardResult() then return GetOnscreenKeyboardResult() end
end

RegisterNUICallback("editline", function(data,cb)
    SetNuiFocus(false,false)
    local result = OpenParameterDialog(255,data.text)
    SendNUIMessage({type = "lineedited", text = result, index = data.index})
    SetNuiFocus(true,true)
end)

RegisterNUICallback("hide",function(data,cb)
    ESX.TriggerServerCallback("fn_notes:editnote", function(success)
        if not success then ESX.ShowNotification("~r~An error occured while communicating with the server. Note not saved.") end
    end, data)
    SetNuiFocus(false, false)
end)

RegisterNetEvent("fn_notes:noteCreated")
AddEventHandler("fn_notes:noteCreated", function(id)
    ESX.UI.Menu.CloseAll()
    SendNUIMessage({type = "toggleshow", id = id, lines = '[]', enable = true})
    SetNuiFocus(true,true)
end)

function OpenNotesMenu()
    ESX.UI.Menu.Close("default",GetCurrentResourceName(),"notes_inventory")
    ESX.UI.Menu.Close("default",GetCurrentResourceName(),"note_actions")
    ESX.TriggerServerCallback("fn_notes:getnotes",function(data)
        local elem = {}
        for _,v in ipairs(data) do
            table.insert(elem,{label = "Note #"..v.id, noteid = v.id})
        end
        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'notes_inventory', {
            title = "Notes inventory",
            align = "top-right",
            elements = elem
        }, function(data,menu)
            if data.current.noteid~=nil and data.current.noteid>0 then
                ESX.TriggerServerCallback("fn_notes:opennote",function(serverdata)
                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'note_actions', {title = "Note #"..data.current.noteid,align="top-right",elements={{label="Open",action="open"},{label="Give to closest player",action="giveclosest"}}},
                    function(data1,menu1)
                        if data1.current.action=="open" then
                            Citizen.CreateThread(function()
                                Citizen.Wait(100)
                                SendNUIMessage({type = "toggleshow", id = serverdata.id, lines = serverdata.content, enable = true})
                                SetNuiFocus(true,true)
                            end)
                        elseif data1.current.action=="giveclosest" then
                            local closestplayer, closestdistance = ESX.Game.GetClosestPlayer()
                            if closestplayer~=-1 and closestdistance<3.0 then
                                TriggerServerEvent("fn_notes:giveClosest",serverdata.id,GetPlayerServerId(closestplayer))
                                ESX.ShowNotification("You gave your note to ~b~"..GetPlayerName(closestplayer))
                            else
                                ESX.ShowNotification("~r~No players nearby")
                            end
                        end
                        menu1.close()
                        menu.close()
                    end,function(data1,menu1)
                        menu1.close()
                    end)
                end, data.current.noteid)
            end
        end, function(data,menu)
            menu.close()
        end)
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, Config.notes_key) then
            OpenNotesMenu()
        end
    end
end)

RegisterCommand("debug", function(a,b,c) SetNuiFocus(false,false) end, false)