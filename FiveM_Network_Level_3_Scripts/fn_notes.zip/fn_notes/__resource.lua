resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'server.lua',
	'config.lua'
}

client_scripts {
	'client.lua',
	'config.lua'
}

files {
	"html/index.html",
	"html/script.js",
	"html/style.css"
}

ui_page 'html/index.html'