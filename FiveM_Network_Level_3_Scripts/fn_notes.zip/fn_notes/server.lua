ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterServerCallback("fn_notes:editnote",function(source,cb,data)
    if not data then return end
    MySQL.Async.execute("UPDATE notes SET content = @content WHERE id = @id",{["@content"] = data.lines, ["@id"] = data.id}, function(rowsChanged)
        cb(rowsChanged>0)
    end)
end)

ESX.RegisterServerCallback("fn_notes:opennote",function(source,cb,id)
    local _source = source
    local identifier = ESX.GetPlayerFromId(_source).getIdentifier()
    local data = MySQL.Async.fetchAll("SELECT * FROM notes WHERE id = @id AND owner = @owner",{["@id"] = id, ["@owner"] = identifier},function(data)
        cb(data[1])
    end)
end)

ESX.RegisterServerCallback("fn_notes:getnotes", function(source,cb)
    local _source = source
    local identifier = ESX.GetPlayerFromId(_source).getIdentifier()
    local data = MySQL.Async.fetchAll("SELECT * FROM notes WHERE owner = @identifier", {["@identifier"] = identifier},function(data)
        cb(data)
    end)
end)

ESX.RegisterUsableItem("note",function(source)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    xPlayer.removeInventoryItem("note",1)
    local identifier = xPlayer.getIdentifier()
    local res = MySQL.Sync.fetchAll("SELECT MAX(id) FROM notes")[1]["MAX(id)"]
    local nextid = res~=nil and res+1 or 1
    MySQL.Async.execute("INSERT INTO notes(id,content,owner) VALUES(@id,@content,@owner)", {["@id"] = nextid, ["@content"] = '[]', ["@owner"] = identifier}, function(rowsChanged)
        TriggerClientEvent("fn_notes:noteCreated", _source, nextid)
    end)
end)

RegisterServerEvent("fn_notes:giveClosest")
AddEventHandler("fn_notes:giveClosest", function(id,target)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local prevowner = xPlayer.getIdentifier()
    local newowner = ESX.GetPlayerFromId(target).getIdentifier()
    MySQL.Async.execute("UPDATE notes SET owner=@newowner WHERE id=@id AND owner=@prevowner",{["@newowner"] = newowner, ["@prevowner"] = prevowner, ["@id"] = id}, function(rowsChanged)
        if rowsChanged<1 then TriggerClientEvent("esx:showNotification",_source,"~r~There was an error communicating with the server. You got your note back") else TriggerClientEvent("esx:showNotification",target,"You received a note from ~b~"..xPlayer.getName()) end
    end)
end)