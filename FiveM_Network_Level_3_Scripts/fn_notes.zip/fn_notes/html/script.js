var curid = 0;



function escapeHtml(unsafe) {
    return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

$(function(){
    $("#main").hide();

    $(".notes").on("click", "td", function(){
        $.post('http://fn_notes/editline', JSON.stringify({index:$("td").index(this), text:$(this).text()}));
    });

    $(".notes").on("contextmenu", "td", function(){
        if($("td").length>1)
            $(this).parent().remove();
    });

    $(".notes").dblclick(function(){
        addLine("");
    });

    window.addEventListener('message', function(event){
		if(event.data.type=="toggleshow") {
            toggleshow(event.data.enable);
            if(event.data.id!=undefined)
                curid = event.data.id;
            if(event.data.lines!=undefined) {
                setText(event.data.lines);
            }
            if(event.data.lines==undefined || JSON.parse(event.data.lines).length<1)
                addLine("");
        }
        if(event.data.type=="addline") {
            addLine(event.data.line);
        }
        if(event.data.type=="lineedited") {
            $($("td")[event.data.index]).text(escapeHtml(event.data.text));
            if(event.data.index==$("td").length-1)
                addLine("");
        }
    });
    
    document.onkeyup = function (data) {
        if (data.which == 27) {
            $.post('http://fn_notes/hide', JSON.stringify({lines:JSON.stringify(getText()), id:curid}));
            toggleshow(false);
        }
    };
});

function toggleshow(show) {
    if(show)
        $("#main").show();
    else
        $("#main").hide();
}

function getText() {
    var lines = [];
    $("td").each(function(i,e){
        lines.push($(e).text());
    });
    return lines;
}

function setText(json) {
    var lines = JSON.parse(json);
    $(".notes").empty();
    lines.forEach(element => {
        $(".notes").append("<tr><td>"+escapeHtml(element)+"</td></tr>");
    });
}

function addLine(text) {
    $(".notes").append("<tr><td>"+escapeHtml(text)+"</td></tr>");
}