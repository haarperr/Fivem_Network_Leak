Config = {}
Config.notes_key = 121 -- INSERT