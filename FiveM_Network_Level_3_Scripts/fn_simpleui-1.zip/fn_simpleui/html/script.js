$(function(){
    window.addEventListener('message', function(event){
        if(event.data.type=="toggle") {
            if(event.data.state)
                $("body").show();
            else
                $("body").hide();
        } else if(event.data.type=="settext") {
            $("span#"+event.data.element).html(event.data.text);
            $("span#"+event.data.element).css("color",event.data.color);
        }
    });
});