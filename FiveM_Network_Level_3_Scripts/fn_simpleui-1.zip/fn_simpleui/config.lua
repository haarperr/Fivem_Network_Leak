Config = {}

Config.hide_radar_hud = true
Config.test = {
    {
        text = "lel",
        color = {1,2,3}
    }
}
Config.hunger = { -- max 1000000
    {
        from = 1000000,
        to = 666666,
        text = "WELL FED",
        color = "rgb(0,255,50)"
    },
    {
        from = 666665,
        to = 333333,
        text = "FED",
        color = "yellow"
    },
    {
        from = 333332,
        to = 0,
        text = "HUNGRY",
        color = "red"
    }
}
Config.thirst = { -- max 1000000
    {
        from = 1000000,
        to = 666666,
        text = "SATURATED",
        color = "rgb(0,255,50)"
    },
    {
        from = 666665,
        to = 333333,
        text = "QUENCHED",
        color = "yellow"
    },
    {
        from = 333332,
        to = 0,
        text = "THIRSTY",
        color = "red"
    }
}
Config.health = { -- health is weird, max is 200, changes show below 150 but ped dies at 99 or less
    {
        from = 200,
        to = 150,
        text = "VERY HEALTHY",
        color = "rgb(0,255,50)"
    },
    {
        from = 149,
        to = 125,
        text = "HEALTHY",
        color = "yellow"
    },
    {
        from = 124,
        to = 100,
        text = "POOR HEALTH",
        color = "red"
    }
}