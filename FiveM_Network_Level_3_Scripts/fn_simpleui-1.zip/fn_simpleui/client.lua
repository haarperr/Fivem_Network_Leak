local thirst,hunger = 0,0

Citizen.CreateThread(function()
    local waspaused = false
    while true do
        Citizen.Wait(0)
        if Config.hide_radar_hud then DisplayRadar(false) end
        if IsPauseMenuActive() and not waspaused then SendNuiMessage(json.encode({type="toggle",state=false})) elseif not IsPauseMenuActive() and waspaused then SendNuiMessage(json.encode({type="toggle",state=true})) end
        waspaused = IsPauseMenuActive()
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        TriggerEvent("esx_status:getStatus","hunger",function(status)
            hunger = status.val
        end)
        TriggerEvent("esx_status:getStatus","thirst",function(status)
            thirst = status.val
        end)
        for _,v in ipairs(Config.health) do
            if v.from>=GetEntityHealth(GetPlayerPed(-1)) and v.to<=GetEntityHealth(GetPlayerPed(-1)) then SendNuiMessage(json.encode({type="settext",element="health",text=v.text,color=v.color})) end
        end
        for _,v in ipairs(Config.thirst) do
            if v.from>=thirst and v.to<=thirst then SendNuiMessage(json.encode({type="settext",element="thirst",text=v.text,color=v.color})) end
        end
        for _,v in ipairs(Config.hunger) do
            if v.from>=hunger and v.to<=hunger then SendNuiMessage(json.encode({type="settext",element="hunger",text=v.text,color=v.color})) end
        end
    end
end)