FEATURES:
- Just a simple health/hunger/thirst UI

REQUIREMENTS:
- ESX
- esx_basicneeds

INSTALLATION:
- Put the resource in your resources directory
- If you want the bars from esx_basicneeds to not show up, change the following in esx_basicneeds:
   client/main.lua line 43 to "return false"
   client/main.lua line 49 to "return false"
- Add this in your server.cfg
   start fn_simpleui

CREDITS:
- Elipse458