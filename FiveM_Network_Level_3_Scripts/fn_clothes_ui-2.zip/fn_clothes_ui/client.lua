ESX = nil
local menu = false
function toggle(state) SetNuiFocus(state,state); menu = state end

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
    end
    if PlayerData==nil then PlayerData = ESX.GetPlayerData() end
end)

RegisterNetEvent('fn_clothes_ui:openMenu')
AddEventHandler('fn_clothes_ui:openMenu', function()
  TriggerEvent('skinchanger:getSkin', function(skin)
    toggle(true)
    SendNUIMessage({
        type = "setSkin",
        data = {
            helmet_1 = skin.helmet_1,
            helmet_2 = skin.helmet_2,
            tshirt_1 = skin.tshirt_1,
            tshirt_2 = skin.tshirt_2,
            torso_1 = skin.torso_1,
            torso_2 = skin.torso_2,
            arms = skin.arms,
            arms_2 = skin.arms_2,
            pants_1 = skin.pants_1,
            pants_2 = skin.pants_2,
            shoes_1 = skin.shoes_1,
            shoes_2 = skin.shoes_2,
            decals_1 = skin.decals_1,
            decals_2 = skin.decals_2
        }
    })
    end)
end)

RegisterNUICallback("start", function(data,cb)
    toggle(false)
end)

RegisterNUICallback("setSkin", function(data,cb)
    if data.apply then
        ESX.TriggerServerCallback("fn_clothes_ui:buyClothes",function(can)
            TriggerEvent('skinchanger:loadSkin', can and data.data or json.decode(data.old))
            if can then TriggerServerEvent('esx_skin:save', data.data) end
        end)
    else
        TriggerEvent('skinchanger:loadSkin', json.decode(data.data))
    end
end)

RegisterNUICallback("toggle", function(data,cb)
    toggle(data.state)
end)

RegisterNUICallback("rotate", function(data,cb)
    SetEntityHeading(GetPlayerPed(-1), GetEntityHeading(GetPlayerPed(-1)) + (data.left and 15 or -15))
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = GetPlayerPed(-1)
        if menu then InvalidateIdleCam() end
        for k,v in ipairs(Config.points) do
            if GetDistanceBetweenCoords(v, GetEntityCoords(ped), false)<15.0 then
                DrawMarker(1, v.x, v.y, v.z-1.0, 0, 0, 0, 0, 0, 0, 1.0001, 1.0001, 0.25, 0, 0, 255, 100, 0, 0, 0, false)
                if GetDistanceBetweenCoords(vector3(v.x,v.y,v.z),GetEntityCoords(ped),false)<1.0 and not menu then
                    ESX.ShowHelpNotification(string.format(Config.help,tostring(Config.price)))
                    if IsControlJustPressed(0, 51) then
                        toggle(true)
                        TriggerEvent('skinchanger:getData', function(components, maxVals)
                            SendNUIMessage({type="setComps",value=json.encode(components)})
                            SendNUIMessage({type="setMaxVals",value=json.encode(maxVals)})
                            TriggerEvent('skinchanger:getSkin', function(skin) SendNUIMessage({type="toggle",state=true,skin=json.encode(skin)}) end)
                        end)
                    end
                end
            end
        end
    end
end)