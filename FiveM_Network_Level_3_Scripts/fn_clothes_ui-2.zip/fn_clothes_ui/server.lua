ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


ESX.RegisterServerCallback("fn_clothes_ui:buyClothes",function(source,cb)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    cb(xPlayer.getMoney()>=Config.price)
    if xPlayer.getMoney()>=Config.price then
        xPlayer.removeMoney(Config.price)
        TriggerClientEvent("esx:showNotification", _source, string.format(Config.pay_message,tostring(Config.price)))
    else
        TriggerClientEvent("esx:showNotification", _source, Config.not_enough_money)
    end
end)