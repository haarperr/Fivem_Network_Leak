let cats = ["https://i.elipse458.me/1483efb","https://i.elipse458.me/8461798","https://i.elipse458.me/33189b4","https://i.elipse458.me/056d249","https://i.elipse458.me/7f1ade3","https://i.elipse458.me/ad30fe4","https://i.elipse458.me/805320b","https://i.elipse458.me/91afb73","https://i.elipse458.me/5464196","https://i.elipse458.me/dd5991a","https://i.elipse458.me/dae7d7f","https://i.elipse458.me/4841ef7"]
let catids = [["helmet_1","helmet_2"],["glasses_1","glasses_2"],["mask_1","mask_2"],["chain_1","chain_2"],["tshirt_1","tshirt_2"],["torso_1","torso_2"],["watches_1","watches_2"],["decals_1","decals_2"],["arms"],["bproof_1","bproof_2"],["pants_1","pants_2"],["shoes_1","shoes_2"]];
var comps;
var vals;
var oldvals;
var maxVals;

function createCategory(img,left,right) {
    var container = $(".row").length%2==0 ? ".container" : ".container2";
    $(container).append('<div class="row" data-left="'+left+'" data-right="'+right+'">' +
    '<button class="fl">&laquo;</button>' +
    '<button class="la">&lsaquo;</button>' +
    '<button class="mb" disabled><img src="'+img+'" height="64" width="64"/></button>' +
    '<button class="ra">&rsaquo;</button>' +
    '<button class="lr">&raquo;</button>' +
    '</div><br>');
    $(".container #bbcontainer").appendTo(".container");
    $(".container2 #bbcontainer").appendTo(".container2");
}

let rb = ["#ff0000","#ff9900","#ffff00","#00ff00","#0000ff","#ff00ff"];
let i = 0;
function rainbow() {
    $("button").animate({"border-top-color": rb[i++%rb.length]}, 2000);
}

function toggle(s) {
    if(s)
        $(".container,.container2").show();
    else
        $(".container,.container2").hide();
}

function getComp(comp) {
    for (let i = 0; i < comps.length; i++) {
        const e = comps[i];
        if(e["name"]==comp)
            return e;
    }
    return undefined;
}

$(function(){
    toggle(false);
    for (let i = 0; i < cats.length; i++) {
        createCategory(cats[i],catids[i][0],catids[i][1]!=undefined ? catids[i][1] : catids[i][0]);
    }
    $(".row button:not(.mb)").click(function(){
        let classs = $(this).attr("class");
        let id = classs=="fl" || classs=="lr" ? $(this).parent().data("right") : $(this).parent().data("left");
        var comp = getComp(id);
        if(comp==undefined)
            return;
        if(classs=="fl" || classs=="la") {
            vals[id] = --vals[id]<comp.min && comp!=undefined ? maxVals[id] : vals[id];
        } else {
            vals[id] = ++vals[id]>maxVals[id] && comp!=undefined ? comp.min : vals[id];
        }
        $.post("http://fn_clothes_ui/setSkin",JSON.stringify({data:JSON.stringify(vals)}));
    });
    $("#apply").click(function(){
        $.post("http://fn_clothes_ui/setSkin",JSON.stringify({data:vals,apply:true,old:oldvals}));
        $.post("http://fn_clothes_ui/toggle",JSON.stringify({state:false}));
        toggle(false);
    });
    $("#cancel").click(function(){
        $.post("http://fn_clothes_ui/setSkin",JSON.stringify({data:oldvals}));
        $.post("http://fn_clothes_ui/toggle",JSON.stringify({state:false}));
        toggle(false);
    });
    $("#leftrotate,#rightrotate").click(function(){
        $.post("http://fn_clothes_ui/rotate",JSON.stringify({left:$(this).attr("id")=="leftrotate"}));
    });
    setInterval(rainbow,2000);
    rainbow();
    window.addEventListener('message', function(event){
        if(event.data.type=="toggle") {
            toggle(event.data.state);
            vals = event.data.skin!=undefined ? JSON.parse(event.data.skin) : vals;
            oldvals = event.data.skin;
        } else if(event.data.type=="setComps") {
            comps=JSON.parse(event.data.value);
        } else if(event.data.type=="setMaxVals") {
            maxVals=JSON.parse(event.data.value);
        } else if(event.data.type=="setSkin") {
            vals=JSON.parse(event.data.data);
        }
    });
    $.post("http://fn_clothes_ui/start", JSON.stringify());
});