Config = {}
Config.price = 45
Config.pay_message = "You paid ~g~$%s~s~ for your new clothes"
Config.not_enough_money = "~r~You don't have enough money!"
Config.help = "Hit ~INPUT_CONTEXT~ to buy new clothes (~r~$%s~s~)"
Config.points = {
    vector3(0,0,0),
    vector3(1,1,1),
    vector3(824.1141,-1012.38,26.30)
}