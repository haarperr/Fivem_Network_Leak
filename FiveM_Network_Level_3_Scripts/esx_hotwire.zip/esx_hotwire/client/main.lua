local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
}


ESX              = nil
local PlayerData = {}

local vehicles = {}
local hotwireVeh = false
local hotwiring = false
local TimeLeft = 0
local engineRunning = true
local LastVeh = 0

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

local function has_value (tab, val)
    for index, value in ipairs(tab) do
        if value == val then
            return true
        end
    end

    return false
end

function round(number, decimals)
    local power = 10^decimals
    return math.floor(number * power) / power
end

function isPlayerJobPolice()
	for k,v in pairs(ESX.GetPlayerData()) do
		for k,v in pairs(k) do
			print(v)
		end
	end
end

function hotwire(veh)
	local inventory = ESX.GetPlayerData().inventory
    local LockpickAmount = nil
    for i=1, #inventory, 1 do                          
        if inventory[i].name == 'lockpick' then
            LockpickAmount = inventory[i].count
        end
    end
    if LockpickAmount > 0 then
    	hotwiring = true
		TimeLeft = cfg.hotwiretime
    	TriggerServerEvent('esx_nocarjack:Remove', 'lockpick', 1)
    	loaddict("anim@veh@std@panto@ds@base")
    	TaskPlayAnim(GetPlayerPed(-1), "anim@veh@std@panto@ds@base", "hotwire", 8.0, -8, -1, 1, 0, 0, 0, 0)
		local result = math.random(1, 100)
		Wait(cfg.hotwiretime*1000)
		if cfg.hotwirechance >= result and hotwiring then	
			hotwireVeh = false
			ClearPedTasks(GetPlayerPed(-1))
			SetVehicleUndriveable(GetVehiclePedIsUsing(GetPlayerPed(-1)), false)
			engineRunning = true
			ESX.ShowNotification("The car started!")
		elseif hotwiring then
			ESX.ShowNotification("You couldn't find right wire")
			ClearPedTasks(GetPlayerPed(-1))
		end
	else
		ESX.ShowNotification("You don't have any lockpick!")
	end
end

function DrawText3D(x, y, z, text, scale)
  local onScreen, _x, _y = World3dToScreen2d(x, y, z)
  local pX, pY, pZ = table.unpack(GetGameplayCamCoords())

  SetTextScale(scale, scale)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextEntry("STRING")
  SetTextCentre(1)
  SetTextColour(255, 255, 255, 255)
  SetTextOutline()

  AddTextComponentString(text)
  DrawText(_x, _y)

  local factor = (string.len(text)) / 270
  DrawRect(_x, _y + 0.015, 0.005 + factor, 0.03, 31, 31, 31, 155)
end

function loaddict(dict)
  while not HasAnimDictLoaded(dict) do
    RequestAnimDict(dict)
    Wait(10)
  end
end

Citizen.CreateThread(function()
	while true do
		Wait(100)

		if hotwiring then
			if TimeLeft > 0 then
				TimeLeft = TimeLeft - 0.1
			else 
				hotwiring = false
			end
		end

	end
end)

Citizen.CreateThread(function()
	while true do
		Wait(0)
		local veh = GetVehiclePedIsUsing(GetPlayerPed(-1))
		local props = ESX.Game.GetVehicleProperties(veh)

		if GetIsTaskActive(GetPlayerPed(-1), 2) and engineRunning and LastVeh == veh then
			LastVeh = 1
			ESX.TriggerServerCallback("esx_nocarjack:checkPlate", function(data)
				if data then
				else
					SetVehicleEngineOn(GetVehiclePedIsUsing(GetPlayerPed(-1)), true, true, true)
				end
			end, GetVehicleNumberPlateText(veh))
			Wait(1500)
		end

		if IsControlJustPressed(0, Keys["X"]) then
            hotwiring = false
            hotwireVeh = true
            ClearPedTasks(GetPlayerPed(-1))
        end

		if hotwireVeh then
			SetVehicleUndriveable(GetVehiclePedIsUsing(GetPlayerPed(-1)), true)
		end

		if hotwiring then
			local coords = GetEntityCoords(GetPlayerPed(-1))
			DisableControlAction(0, 75, true)
			DrawText3D(coords.x, coords.y, coords.z, "~r~".. round(TimeLeft, 1), 0.4)
		end

	end
end)

Citizen.CreateThread(function()
	while true do
		Wait(0)
		local ped = GetPlayerPed(-1)
		local coords = GetEntityCoords(ped)
		local veh = GetVehiclePedIsUsing(ped)

		if IsPedInAnyVehicle(ped, false) and not hotwiring and hotwireVeh then
			DrawText3D(coords.x, coords.y, coords.z, "~g~[E]~w~ Hotwire", 0.4)
			if IsControlJustPressed(0, Keys["E"]) then
                hotwire(veh)
          	end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		-- gets if player is entering vehicle
		if DoesEntityExist(GetVehiclePedIsTryingToEnter(PlayerPedId())) then
			-- gets vehicle player is trying to enter and its lock status
			local xPlayer = ESX.GetPlayerData()
			local veh = GetVehiclePedIsTryingToEnter(PlayerPedId())
			local lock = GetVehicleDoorLockStatus(veh)
			local props = ESX.Game.GetVehicleProperties(veh)
				
				-- Get the conductor door angle, open if value > 0.0
				local doorAngle = GetVehicleDoorAngleRatio(veh, 0)
			
				-- normalizes chance
				if cfg.chance > 100 then
					cfg.chance = 100
				elseif cfg.chance < 0 then
					cfg.chance = 0
				end
			
				-- check if got lucky
				local lucky = (math.random(100) < cfg.chance)
			
				-- Set lucky if conductor door is open
				if doorAngle > 0.0 then
					lucky = true
				end
			
				-- check if vehicle is in blacklist
				local backlisted = false
				for k,model in pairs(cfg.blacklist) do
					if IsVehicleModel(veh, GetHashKey(model)) then
						blacklisted = true
					end
				end

				-- check if vehicle is in white list
				local whitelisted = false
				for k,model in pairs(cfg.whitelist) do
					if IsVehicleModel(veh, GetHashKey(model)) then
						whitelisted = true
					end
				end

				-- gets ped that is driving the vehicle
				local pedd = GetPedInVehicleSeat(veh, -1)
				local plate = GetVehicleNumberPlateText(veh)
				-- lock doors if not lucky or blacklisted
				if (lock == 7 or pedd) then
					if has_value(cfg.whitelist, xPlayer.job.name) then
						TriggerServerEvent('esx_nocarjack:setVehicleDoorsForEveryone', {veh, 1, plate})
					else
						if not IsVehicleSeatFree(veh, -1) then
							TriggerServerEvent('esx_nocarjack:setVehicleDoorsForEveryone', {veh, 2, plate})
						elseif not lucky or blacklisted then
							TriggerServerEvent('esx_nocarjack:setVehicleDoorsForEveryone', {veh, 2, plate})
						else
							TriggerServerEvent('esx_nocarjack:setVehicleDoorsForEveryone', {veh, 1, plate})
							if not GetIsVehicleEngineRunning(veh) and veh ~= 0 and LastVeh ~= veh then
								engineRunning = false
								LastVeh = veh
								ESX.TriggerServerCallback("esx_nocarjack:checkPlate", function(data)
									if whitelisted or data or not GetPedInVehicleSeat(veh, -1) or PlayerData.job == 'police' or  PlayerData.job == 'ambulance' or  PlayerData.group == 'admin' or  PlayerData.group == 'superadmin' then
									else
										hotwireVeh = true
									end
								end, GetVehicleNumberPlateText(veh))
								Wait(1500)
							end
						end
					end
				end
			end
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx_nocarjack:setVehicleDoors')
AddEventHandler('esx_nocarjack:setVehicleDoors', function(veh, doors)
	SetVehicleDoorsLocked(veh, doors)
end)