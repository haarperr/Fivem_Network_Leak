cfg = {}

cfg.chance = 100 -- chance of being unlocked in percentage

cfg.hotwirechance = 75 -- chance of being hotwired in percentage
cfg.hotwiretime = 7.0 -- how long hotwire should take in seconds

cfg.blacklist = { -- vehicles that will always be locked when spawned naturally
  "T20",
  "police",
  "police2",
  "sheriff3",
  "sheriff2",
  "sheriff",
  "riot",
  "fbi",
  "hwaycar2",
  "hwaycar3",
  "hwaycar10",
  "hwaycar",
  "polf430",
  "policeb",
  "police7",
  "RHINO"
}

cfg.whitelist = {
  "police",
  "ambulance"
}