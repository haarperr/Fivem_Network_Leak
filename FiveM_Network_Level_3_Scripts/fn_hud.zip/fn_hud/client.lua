ESX = nil

local PlayerData = {}

Citizen.CreateThread(function ()
    while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    PlayerData = ESX.GetPlayerData()

    while PlayerData ~= nil do
        Wait(1000)
        Seton()
    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

RegisterNetEvent("fn_hud:sendStatus")
AddEventHandler("fn_hud:sendStatus", function(cash, bank, dirty)
    --Seton(cash, bank, dirty, PlayerData.job.label .. " - " .. PlayerData.job.grade_label)
    print('sent')
end)

function Seton()
    ESX.TriggerServerCallback('fn_hud:getStatus', function(data)
        SendNUIMessage({
            cash = data.money,
            bank = data.bank,
            dirty = data.black_money,
            job = PlayerData.job.label,
            job_grade = PlayerData.job.grade_label
        })
    end)
end