$(function(){

    window.addEventListener('message', function(event){
        var item = event.data;
        console.log(item.job_grade)
        $("#cash").text(item.cash);
        $("#bank").text(item.bank);
        $("#dirty").text(item.dirty);
        $("#name").text(item.job);
        $("#grade").text(item.job_grade);
})

});