ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

AddEventHandler('es:playerLoaded', function(source)
	local Identifier = GetPlayerIdentifiers(source)[1]
	local now = os.time()
	MySQL.Async.fetchAll('SELECT * FROM `daily_free` WHERE `identifier`=@identifier;', {['@identifier'] = Identifier}, function(collect)
		if collect[1] then
			TriggerClientEvent("free:setTimeout", source, collect[1].next_collect + 300)
		else
			MySQL.Async.execute('INSERT INTO `daily_free` (`identifier`, `next_collect`, `times_collected`) VALUES (@identifier, @nextcollect, 0);', {['@identifier'] = Identifier, ['@nextcollect'] = now}, nil)
			TriggerClientEvent("free:setTimeout", source, now + 300)
		end
	end)
end)

RegisterServerEvent("free:updateTimeout")
AddEventHandler("free:updateTimeout", function()
	local _source = source
	local Identifier = GetPlayerIdentifiers(_source)[1]
	local now = os.time()
	MySQL.Async.fetchAll('SELECT `next_collect` FROM `daily_free` WHERE `identifier`=@identifier;', {['@identifier'] = Identifier}, function(collect)
		if collect[1] then
			TriggerClientEvent("free:setTimeout", _source, collect[1].next_collect)
		else
			TriggerClientEvent("free:setTimeout", _source, now)
		end
	end)
end)

function claimRewards(xPlayer)
	for k,v in ipairs(Config.rewards) do
		if v.type==1 and v.value then
			xPlayer.addMoney(v.value)
		elseif v.type==2 and v.item and v.count then
			xPlayer.addInventoryItem(v.item,v.count)
		end
	end
end

RegisterServerEvent("free:collect")
AddEventHandler("free:collect", function(t)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local Identifier = xPlayer.identifier
	local now = os.time()
	local nextcollect = os.time() + 86399
	MySQL.Async.fetchAll('SELECT * FROM `daily_free` WHERE `identifier`=@identifier;', {['@identifier'] = Identifier}, function(collect)
		if collect[1] then
			if collect[1].next_collect < now then
				claimRewards(xPlayer)
				TriggerClientEvent("esx:showNotification",_source,Config.claimed)
				TriggerClientEvent("free:toggleFreeMenu", _source, false)
				MySQL.Async.execute('UPDATE `daily_free` SET `next_collect`=@nextcollect,`times_collected`=@timescollected WHERE `identifier`=@identifier', {["@identifier"] = Identifier, ["@nextcollect"] = nextcollect, ["@timescollected"] = collect[1].times_collected+1}, nil)
				TriggerClientEvent("free:setTimeout", _source, nextcollect)
			else
				TriggerClientEvent("free:setTimeout", _source, collect[1].next_collect)
				TriggerClientEvent("chatMessage", _source, "Daily Free", {255,0,0}, "It's still not time...")
			end
		else
			claimRewards(xPlayer)
			TriggerClientEvent("esx:showNotification",_source,Config.claimed)
			TriggerClientEvent("free:setTimeout", _source, nextcollect)
			TriggerClientEvent("free:toggleFreeMenu", _source, false)
			MySQL.Async.execute('INSERT INTO `daily_free` (`identifier`, `next_collect`, `times_collected`) VALUES (@identifier, @nextcollect, 1);', {['@identifier'] = Identifier, ['@nextcollect'] = nextcollect}, nil)
		end
	end)
end)

TriggerEvent('es:addCommand', 'daily', function(source, args, user)
	TriggerClientEvent("free:toggleFreeMenu", source, true)
end)