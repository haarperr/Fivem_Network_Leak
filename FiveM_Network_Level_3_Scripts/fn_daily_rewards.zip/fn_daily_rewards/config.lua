local type = {money=1,item=2}
Config = {}
Config.claimed = "~g~You claimed your daily reward"
Config.rewards = {
    {
        type = type.money,
        value = 1000
    },
    {
        type = type.item,
        item = "bread",
        count = 3
    },
    {
        type = type.item,
        item = "water",
        count = 5
    }
}