var Config = {
    header : "Daily rewards",
    remaining : "Remaining",
    countdown_done : "Your daily reward is ready",
    button : "Claim"
};