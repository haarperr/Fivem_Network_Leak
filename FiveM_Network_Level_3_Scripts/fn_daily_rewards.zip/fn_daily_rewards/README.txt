FEATURES:
- Commad /daily - brings up daily menu
- After player joins, 5 minutes are added to the counter so they can't redeem right after joining

REQUIREMENTS:
- ESX

INSTALLATION:
- Import sql.sql in your database
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_daily_rewards
- If you need to restart this resource, restart your whole server

CREDITS:
- Elipse458
