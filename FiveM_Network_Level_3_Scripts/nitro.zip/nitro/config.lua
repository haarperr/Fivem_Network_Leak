Config = {}

Config.Nitro = {
  Power = 25.0,
  Torque = 5.0
}

Config.consumption = 200 -- defines how fast will consume 1% of nitro in ms