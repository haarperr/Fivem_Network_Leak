client_script {
	'object_loader.lua',
	'xml.lua',
}

export 'getSpawns'