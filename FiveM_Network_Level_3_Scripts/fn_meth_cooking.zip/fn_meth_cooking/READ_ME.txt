FEATURES:
- Allows you to cook meth in a certain location
- You can set the order in which ingredients can be put in along with what heat needs to be set to before putting it in

REQUIREMENTS:
- ESX
- esx_drugs_custom (https://github.com/madhatter23412/esx_drugs_custom)

INSTALLATION:
- Import sql.sql in your database
- Put the resource in your resources directory
- Add this in your server.cfg
   start fn_meth_cooking

CREDITS:
- Elipse458
